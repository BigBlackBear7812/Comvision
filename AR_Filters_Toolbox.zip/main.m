function main()
%MAIN  Open the Smart AR Image Processing Toolbox.
%   From MATLAB, cd to this folder and run:
%       main
%   Topic 13 — Creating Augmented Reality Filters.
%   The three modules are image enhancement, segmentation, and geometry.

root = fileparts(mfilename('fullpath'));
addpath(genpath(root));
launchToolbox();
end

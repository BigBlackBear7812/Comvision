function runDemo()
%RUNDEMO  Recompute the sample outputs with the MATLAB functions.
%   Writes results/matlab_run so the labeled plates in results/ stay intact.
%   Student 3.

root = fileparts(mfilename('fullpath'));
addpath(genpath(root));
outDir = fullfile(root, 'results', 'matlab_run');
if ~exist(outDir, 'dir')
    mkdir(outDir);
end
portrait = toDouble(imread(fullfile(root, 'samples', 'portrait.png')));
dark = toDouble(imread(fullfile(root, 'samples', 'portrait_dark.png')));
noisy = toDouble(imread(fullfile(root, 'samples', 'portrait_noise.png')));
house = toDouble(imread(fullfile(root, 'samples', 'house.png')));
shapes = toDouble(imread(fullfile(root, 'samples', 'shapes.png')));
grid = toDouble(imread(fullfile(root, 'samples', 'grid.png')));

saveOut(outDir, 'm1_equalize.png', histogramEqualize(dark));
saveOut(outDir, 'm1_median.png', spatialMedianFilter(noisy, 3));
saveOut(outDir, 'm1_lowpass.png', frequencyFilter(portrait, 'lowpass', 28, 20, 'gaussian'));
saveOut(outDir, 'm1_ideal_lowpass.png', frequencyFilter(asGray(portrait), 'lowpass', 30, 20, 'ideal'));
[~, sobel] = sobelEdge(house, 0.18);
[~, prewitt] = prewittEdge(house, 0.18);
[~, canny] = cannyEdge(house, 1.4, 0.04, 0.14);
saveOut(outDir, 'm2_sobel.png', sobel);
saveOut(outDir, 'm2_prewitt.png', prewitt);
saveOut(outDir, 'm2_canny.png', canny);
[level, mask] = otsuThreshold(shapes);
fprintf('Otsu level on shapes: %d\n', level);
saveOut(outDir, 'm2_otsu.png', mask);
[circles, ~] = shapeSegmentation(mask);
saveOut(outDir, 'm2_circles.png', circles);
saveOut(outDir, 'm3_rotate.png', rotateImage(portrait, 18, 'bilinear'));
saveOut(outDir, 'm3_forward.png', rotateImage(asGray(portrait), 18, 'nearest', 'forward'));
filters = {'glasses', 'mustache', 'hat', 'party', 'dog', 'combo', 'beauty', 'bgblur', 'colorpop'};
for k = 1:numel(filters)
    out = applyARFilter(portrait, filters{k}, 'bilinear', false, 1);
    saveOut(outDir, ['ar_', filters{k}, '.png'], out);
end
info = detectFaceRegions(portrait);
fprintf('Faces: %d, eye source: %s, eye distance: %.1f\n', ...
    numel(info.faces), info.faces(1).eyeSource, info.faces(1).eyeDist);
fprintf('Demo images written to %s\n', outDir);
end

function saveOut(outDir, name, img)
imwrite(toUint8Image(img), fullfile(outDir, name));
end

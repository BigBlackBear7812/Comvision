function out = spatialMeanFilter(img, ksize)
%SPATIALMEANFILTER  Box average. Student 1.
%   Kernel is ones(k) / k^2 with replicate borders. Odd k only.

if nargin < 2, ksize = 3; end
ksize = max(1, round(ksize));
if mod(ksize, 2) == 0, ksize = ksize + 1; end
src = toDouble(img);
kernel = ones(ksize) / (ksize * ksize);
out = applyPlane(src, @(p) filter2(kernel, p, 'same'));
end

function out = histogramMatch(src, ref)
%HISTOGRAMMATCH  Map the source luminance CDF onto the reference CDF.
%   Student 1. For each source level i, pick the smallest reference
%   level whose CDF is at least the source CDF.

srcF = toDouble(src);
ref8 = uint8(round(asGray(ref) * 255));
refCdf = cumsum(histcounts(ref8(:), -0.5:255.5));
refCdf = refCdf / refCdf(end);

    function matched = matchPlane(channel)
        s8 = uint8(round(channel * 255));
        sCdf = cumsum(histcounts(s8(:), -0.5:255.5));
        sCdf = sCdf / max(sCdf(end), 1);
        mapping = zeros(1, 256, 'uint8');
        j = 1;
        for i = 1:256
            while j < 256 && refCdf(j) < sCdf(i)
                j = j + 1;
            end
            mapping(i) = j - 1;
        end
        matched = double(mapping(double(s8) + 1)) / 255;
    end

if ndims(srcF) == 2 || size(srcF, 3) == 1
    out = matchPlane(srcF(:, :, 1));
else
    ycbcr = rgb2ycbcrLocal(srcF);
    ycbcr(:, :, 1) = matchPlane(ycbcr(:, :, 1));
    out = ycbcr2rgbLocal(ycbcr);
end
end

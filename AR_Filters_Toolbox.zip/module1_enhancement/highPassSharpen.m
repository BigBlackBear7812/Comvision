function out = highPassSharpen(img, ksize, amount)
%HIGHPASSSHARPEN  Unsharp mask g = f + amount * (f - box(f)). Student 1.

if nargin < 2, ksize = 5; end
if nargin < 3, amount = 1; end
src = toDouble(img);
blur = spatialMeanFilter(src, ksize);
out = min(max(src + amount * (src - blur), 0), 1);
end

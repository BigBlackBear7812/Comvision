function out = frequencyFilter(img, kind, d0, width, response)
%FREQUENCYFILTER  Low-pass, high-pass, or band-pass via FFT. Student 1.
%   The image is padded to 2M x 2N and recentered with (-1)^(x+y),
%   following Gonzalez and Woods, so the filter origin sits at the center.
%   response is 'gaussian' or 'ideal'. Ideal low-pass shows ringing.

if nargin < 2, kind = 'lowpass'; end
if nargin < 3 || isempty(d0), d0 = 40; end
if nargin < 4 || isempty(width), width = 20; end
if nargin < 5 || isempty(response), response = 'gaussian'; end
src = toDouble(img);
out = applyPlane(src, @(p) filterPlane(p, kind, d0, width, response));
end

function out = filterPlane(f, kind, d0, width, response)
[m, n] = size(f);
P = 2 * m;
Q = 2 * n;
fp = zeros(P, Q);
fp(1:m, 1:n) = f;
[yy, xx] = ndgrid(0:P - 1, 0:Q - 1);
center = (-1) .^ (xx + yy);
fp = fp .* center;
spec = fft2(fp);
dist = sqrt((yy - P / 2) .^ 2 + (xx - Q / 2) .^ 2);
if strcmpi(response, 'ideal')
    switch lower(kind)
        case 'lowpass'
            transfer = double(dist <= d0);
        case 'highpass'
            transfer = double(dist >= d0);
        case 'bandpass'
            transfer = double(dist >= d0 - width / 2 & dist <= d0 + width / 2);
        otherwise
            transfer = 1 - double(dist >= d0 - width / 2 & dist <= d0 + width / 2);
    end
else
    low = exp(-(dist .^ 2) ./ (2 * (d0 ^ 2) + 1e-8));
    switch lower(kind)
        case 'lowpass'
            transfer = low;
        case 'highpass'
            transfer = 1 - low;
        otherwise
            ring = exp(-((dist .^ 2 - d0 ^ 2) .^ 2) ./ ((dist * width) .^ 2 + 1e-8));
            if strcmpi(kind, 'bandpass')
                transfer = ring;
            else
                transfer = 1 - ring;
            end
    end
end
rec = real(ifft2(spec .* transfer)) .* center;
out = min(max(rec(1:m, 1:n), 0), 1);
end

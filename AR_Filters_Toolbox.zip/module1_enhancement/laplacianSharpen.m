function out = laplacianSharpen(img, amount)
%LAPLACIANSHARPEN  g = f - amount * Laplacian(f). Student 1.
%   Kernel [0 1 0; 1 -4 1; 0 1 0]. Positive amount strengthens edges.

if nargin < 2, amount = 1; end
src = toDouble(img);
kernel = [0 1 0; 1 -4 1; 0 1 0];
out = applyPlane(src, @(p) min(max(p - amount * filter2(kernel, p, 'same'), 0), 1));
end

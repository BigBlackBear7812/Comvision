function out = histogramEqualize(img)
%HISTOGRAMEQUALIZE  Equalize luminance, keep chrominance. Student 1.
%   s = round( (cdf - cdfmin) / (N - cdfmin) * 255 ).
%   Color images are converted to YCbCr so hue does not wash out.
%   The AR tool uses this on underexposed frames before drawing a filter.

src = toDouble(img);
if ndims(src) == 2 || size(src, 3) == 1
    g = uint8(round(src(:, :, 1) * 255));
    map = cdfMap(g);
    out = double(map(double(g) + 1)) / 255;
    return;
end
ycbcr = rgb2ycbcrLocal(src);
y8 = uint8(round(ycbcr(:, :, 1) * 255));
map = cdfMap(y8);
ycbcr(:, :, 1) = double(map(double(y8) + 1)) / 255;
out = ycbcr2rgbLocal(ycbcr);
end

function map = cdfMap(values)
histCounts = histcounts(values(:), -0.5:255.5);
cdf = cumsum(histCounts);
cdfMin = cdf(find(cdf > 0, 1, 'first'));
total = numel(values);
map = uint8(round((cdf - cdfMin) / max(total - cdfMin, 1) * 255));
end

function out = spatialMedianFilter(img, ksize)
%SPATIALMEDIANFILTER  Median of a kxk neighborhood. Student 1.
%   Removes salt-and-pepper noise without the blur of the mean filter.
%   The beauty filter calls this on skin pixels.

if nargin < 2, ksize = 3; end
ksize = max(1, round(ksize));
if mod(ksize, 2) == 0, ksize = ksize + 1; end
src = toDouble(img);
out = applyPlane(src, @(p) medianPlane(p, ksize));
end

function out = medianPlane(plane, ksize)
r = floor(ksize / 2);
pad = replicatePad(plane, r);
[h, w] = size(plane);
stack = zeros(h, w, ksize * ksize);
t = 1;
for dy = 0:ksize - 1
    for dx = 0:ksize - 1
        stack(:, :, t) = pad(dy + (1:h), dx + (1:w));
        t = t + 1;
    end
end
out = median(stack, 3);
end

function p = replicatePad(img, r)
[h, w] = size(img);
rows = min(max((1:(h + 2 * r)) - r, 1), h);
cols = min(max((1:(w + 2 * r)) - r, 1), w);
p = img(rows, cols);
end

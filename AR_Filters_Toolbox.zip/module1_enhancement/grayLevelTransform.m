function out = grayLevelTransform(img, mode, amount, contrast, gammaValue)
%GRAYLEVELTRANSFORM  Point operations. Student 1.
%   mode: 'brightness', 'contrast', 'both', 'gamma', 'negative', 'log'.
%   brightness amount is added in [0, 1]. contrast scales about 0.5.

if nargin < 3, amount = 0; end
if nargin < 4, contrast = 1; end
if nargin < 5, gammaValue = 1; end
src = toDouble(img);
switch lower(mode)
    case 'brightness'
        out = src + amount;
    case 'contrast'
        out = (src - 0.5) * contrast + 0.5;
    case 'both'
        out = (src - 0.5) * contrast + 0.5 + amount;
    case 'gamma'
        out = src .^ gammaValue;
    case 'negative'
        out = 1 - src;
    case 'log'
        c = 1 / log(2);
        out = c * log1p(src);
    otherwise
        error('grayLevelTransform:Mode', 'Unknown mode "%s".', mode);
end
out = min(max(out, 0), 1);
end

function launchToolbox()
%LAUNCHTOOLBOX  GUI for the three modules and the AR filters.
%   Student 3 integrated the interface. Each tab calls one module.

root = fileparts(mfilename('fullpath'));
addpath(genpath(root));

S.img = [];
S.result = [];
S.ref = [];
S.moving = [];
S.seed = [471, 321];
S.cam = [];
S.timer = [];

fig = uifigure('Name', 'Smart AR Image Processing Toolbox', ...
    'Position', [60 40 1280 820], 'Color', [0.97 0.97 0.98]);
fig.CloseRequestFcn = @onClose;

uilabel(fig, 'Position', [24 778 900 28], 'FontSize', 18, 'FontWeight', 'bold', ...
    'Text', 'Smart AR Image Processing Toolbox');
uilabel(fig, 'Position', [24 754 900 22], 'FontSize', 12, ...
    'Text', 'Topic 13  Creating Augmented Reality Filters    |    three modules, one interface');

ax1 = uiaxes(fig, 'Position', [20 250 600 490]);
ax2 = uiaxes(fig, 'Position', [650 250 600 490]);
styleAxes(ax1, 'Original');
styleAxes(ax2, 'Result');

status = uilabel(fig, 'Position', [24 222 1100 22], 'FontSize', 12, ...
    'Text', 'Load an image. A ready-made portrait is in samples/portrait.png.');

uibutton(fig, 'Text', 'Load image', 'Position', [24 184 120 30], 'ButtonPushedFcn', @onLoad);
uibutton(fig, 'Text', 'Save result', 'Position', [156 184 120 30], 'ButtonPushedFcn', @onSave);
uibutton(fig, 'Text', 'Apply', 'Position', [288 184 120 30], 'ButtonPushedFcn', @onApply, ...
    'BackgroundColor', [0.20 0.45 0.75], 'FontColor', 'white');
uibutton(fig, 'Text', 'Reset', 'Position', [420 184 120 30], 'ButtonPushedFcn', @onReset);

tabs = uitabgroup(fig, 'Position', [16 12 1248 164]);
tabAR = uitab(tabs, 'Title', 'AR Filters');
tabE = uitab(tabs, 'Title', '1  Enhancement');
tabS = uitab(tabs, 'Title', '2  Segmentation');
tabG = uitab(tabs, 'Title', '3  Geometry');
tabT = uitab(tabs, 'Title', 'Team');

arFilter = uidropdown(tabAR, 'Position', [16 78 180 28], ...
    'Items', {'glasses', 'mustache', 'hat', 'party', 'dog', 'combo', 'beauty', 'bgblur', 'colorpop'});
arMethod = uidropdown(tabAR, 'Position', [210 78 140 28], ...
    'Items', {'bilinear', 'nearest', 'bicubic'}, 'Value', 'bilinear');
arScale = uislider(tabAR, 'Position', [380 100 180 3], 'Limits', [0.6 1.6], 'Value', 1);
uilabel(tabAR, 'Position', [380 108 180 18], 'Text', 'Overlay scale');
arEnhance = uicheckbox(tabAR, 'Text', 'Equalize dark frame', 'Position', [590 84 160 22], 'Value', false);
arMarks = uicheckbox(tabAR, 'Text', 'Show landmarks', 'Position', [760 84 140 22], 'Value', true);
uibutton(tabAR, 'Text', 'Camera', 'Position', [920 78 110 28], 'ButtonPushedFcn', @onCamera);
uilabel(tabAR, 'Position', [16 28 1100 36], 'Text', ['Glasses, hat, mustache, and dog ears are anchored to the eyes. ', ...
    'Beauty uses the median filter on skin. Background blur uses the frequency low-pass. ', ...
    'Color pop keeps red and drops other saturation.']);

enhOp = uidropdown(tabE, 'Position', [16 78 220 28], 'Items', { ...
    'Histogram equalization', 'Histogram matching', 'Brightness / contrast', ...
    'Gamma', 'Negative', 'Log', 'Mean filter', 'Median filter', ...
    'Laplacian sharpen', 'Unsharp mask', 'Gaussian low-pass', ...
    'Gaussian high-pass', 'Gaussian band-pass', 'Ideal low-pass'});
enhKernel = uislider(tabE, 'Position', [260 100 140 3], 'Limits', [3 9], 'Value', 3);
enhBright = uislider(tabE, 'Position', [420 100 140 3], 'Limits', [-0.4 0.4], 'Value', 0.1);
enhContrast = uislider(tabE, 'Position', [580 100 140 3], 'Limits', [0.4 2.4], 'Value', 1.3);
enhGamma = uislider(tabE, 'Position', [740 100 120 3], 'Limits', [0.3 2.5], 'Value', 0.7);
enhD0 = uislider(tabE, 'Position', [880 100 140 3], 'Limits', [8 80], 'Value', 30);
uilabel(tabE, 'Position', [260 108 140 16], 'Text', 'Kernel');
uilabel(tabE, 'Position', [420 108 140 16], 'Text', 'Brightness');
uilabel(tabE, 'Position', [580 108 140 16], 'Text', 'Contrast');
uilabel(tabE, 'Position', [740 108 120 16], 'Text', 'Gamma');
uilabel(tabE, 'Position', [880 108 140 16], 'Text', 'Cutoff D0');
uibutton(tabE, 'Text', 'Load reference', 'Position', [1040 78 150 28], 'ButtonPushedFcn', @onRef);
uilabel(tabE, 'Position', [16 24 1180 36], 'Text', ...
    'Student 1. Histogram matching needs a reference image. Frequency filters pad to 2M x 2N before the FFT.');

segOp = uidropdown(tabS, 'Position', [16 78 200 28], 'Items', { ...
    'Sobel', 'Prewitt', 'Canny', 'Compare edges', 'Otsu', 'Region growing', ...
    'Color red', 'Color blue', 'Color green', 'Color skin', ...
    'Dilate', 'Erode', 'Open', 'Close', 'Shape circles'});
segTol = uislider(tabS, 'Position', [240 100 140 3], 'Limits', [0.04 0.45], 'Value', 0.20);
uilabel(tabS, 'Position', [240 108 140 16], 'Text', 'Region tolerance');
uilabel(tabS, 'Position', [400 108 80 16], 'Text', 'Seed row');
seedRow = uieditfield(tabS, 'numeric', 'Position', [400 78 80 26], 'Value', 471);
uilabel(tabS, 'Position', [490 108 80 16], 'Text', 'Seed column');
seedCol = uieditfield(tabS, 'numeric', 'Position', [490 78 80 26], 'Value', 321);
segRadius = uislider(tabS, 'Position', [600 100 140 3], 'Limits', [1 8], 'Value', 3);
uilabel(tabS, 'Position', [600 108 140 16], 'Text', 'Morph radius');
uilabel(tabS, 'Position', [16 24 1180 36], 'Text', ...
    'Student 2. Click is not required: type a 1-based seed, or leave 471, 321 for the sample cheek. Shape keeps components with circularity above 1.');

geoOp = uidropdown(tabG, 'Position', [16 78 200 28], 'Items', { ...
    'Translate', 'Scale', 'Rotate', 'Forward rotate', 'Shear', ...
    'Barrel distort', 'Undistort', 'Register'});
geoMethod = uidropdown(tabG, 'Position', [230 78 130 28], ...
    'Items', {'bilinear', 'nearest', 'bicubic'}, 'Value', 'bilinear');
geoTx = uislider(tabG, 'Position', [390 100 120 3], 'Limits', [-80 80], 'Value', 40);
geoTy = uislider(tabG, 'Position', [530 100 120 3], 'Limits', [-80 80], 'Value', -30);
geoAngle = uislider(tabG, 'Position', [670 100 130 3], 'Limits', [-40 40], 'Value', 18);
geoScale = uislider(tabG, 'Position', [820 100 120 3], 'Limits', [0.5 2], 'Value', 1.4);
geoK = uislider(tabG, 'Position', [960 100 120 3], 'Limits', [-0.45 0.2], 'Value', -0.22);
uilabel(tabG, 'Position', [390 108 120 16], 'Text', 'tx');
uilabel(tabG, 'Position', [530 108 120 16], 'Text', 'ty');
uilabel(tabG, 'Position', [670 108 130 16], 'Text', 'Angle');
uilabel(tabG, 'Position', [820 108 120 16], 'Text', 'Scale');
uilabel(tabG, 'Position', [960 108 120 16], 'Text', 'k1');
uibutton(tabG, 'Text', 'Load moving', 'Position', [1100 78 120 28], 'ButtonPushedFcn', @onMoving);
uilabel(tabG, 'Position', [16 18 1200 40], 'Text', ...
    'Student 3. Positive angle is counterclockwise. Forward rotate shows holes. Register aligns the moving image onto the image in the original pane.');

teamText = uitextarea(tabT, 'Position', [12 8 1210 112], 'Editable', 'off', 'Value', { ...
    'Student 1 — Enhancement. Histogram equalization and matching, brightness, contrast, gamma, mean, median, Laplacian, unsharp mask, FFT low/high/band pass. Used by the beauty filter and by background blur.'; ...
    'Student 2 — Segmentation. Sobel, Prewitt, Canny, Otsu, region growing, HSV color ranges, morphology, shape circularity, and the skin/eye landmarks that anchor every AR filter.'; ...
    'Student 3 — Geometry and integration. Translation, scale, rotation, forward versus reverse mapping, affine shear, radial distortion, Harris + RANSAC registration, sprite placement, and this GUI.'; ...
    'Replace Student 1, Student 2, and Student 3 with the real names and IDs on the report cover before submission.'});

    function onLoad(~, ~)
        [file, path] = uigetfile({'*.png;*.jpg;*.jpeg;*.bmp;*.tif', 'Images'}, 'Open image');
        if isequal(file, 0)
            return;
        end
        S.img = toDouble(imread(fullfile(path, file)));
        S.result = S.img;
        showBoth();
        setStatus(['Loaded ', file]);
    end

    function onRef(~, ~)
        [file, path] = uigetfile({'*.png;*.jpg;*.jpeg;*.bmp', 'Images'}, 'Reference for histogram matching');
        if isequal(file, 0)
            return;
        end
        S.ref = toDouble(imread(fullfile(path, file)));
        setStatus(['Reference ', file]);
    end

    function onMoving(~, ~)
        [file, path] = uigetfile({'*.png;*.jpg;*.jpeg;*.bmp', 'Images'}, 'Moving image for registration');
        if isequal(file, 0)
            return;
        end
        S.moving = toDouble(imread(fullfile(path, file)));
        setStatus(['Moving image ', file]);
    end

    function onSave(~, ~)
        if isempty(S.result)
            setStatus('Nothing to save.');
            return;
        end
        [file, path] = uiputfile('result.png', 'Save result');
        if isequal(file, 0)
            return;
        end
        imwrite(toUint8Image(S.result), fullfile(path, file));
        setStatus(['Saved ', file]);
    end

    function onReset(~, ~)
        S.result = S.img;
        showBoth();
        setStatus('Result reset to the original.');
    end

    function onApply(~, ~)
        if isempty(S.img)
            setStatus('Load an image first.');
            return;
        end
        try
            switch tabs.SelectedTab.Title
                case 'AR Filters'
                    S.result = runAR();
                case '1  Enhancement'
                    S.result = runEnhancement();
                case '2  Segmentation'
                    S.result = runSegmentation();
                case '3  Geometry'
                    S.result = runGeometry();
                otherwise
                    setStatus('The team tab has no image operation.');
                    return;
            end
            showBoth();
        catch err
            setStatus(['Error: ', err.message]);
        end
    end

    function out = runAR()
        name = arFilter.Value;
        out = applyARFilter(S.img, name, arMethod.Value, arEnhance.Value, arScale.Value);
        if arMarks.Value && any(strcmp(name, {'glasses', 'mustache', 'hat', 'party', 'dog', 'combo'}))
            info = detectFaceRegions(S.img);
            out = drawLandmarks(out, info);
        end
        setStatus(['AR filter: ', name]);
    end

    function out = runEnhancement()
        ksize = oddFrom(enhKernel.Value);
        switch enhOp.Value
            case 'Histogram equalization'
                out = histogramEqualize(S.img);
            case 'Histogram matching'
                if isempty(S.ref)
                    error('Load a reference image first.');
                end
                out = histogramMatch(S.img, S.ref);
            case 'Brightness / contrast'
                out = grayLevelTransform(S.img, 'both', enhBright.Value, enhContrast.Value);
            case 'Gamma'
                out = grayLevelTransform(S.img, 'gamma', 0, 1, enhGamma.Value);
            case 'Negative'
                out = grayLevelTransform(S.img, 'negative');
            case 'Log'
                out = grayLevelTransform(S.img, 'log');
            case 'Mean filter'
                out = spatialMeanFilter(S.img, ksize);
            case 'Median filter'
                out = spatialMedianFilter(S.img, ksize);
            case 'Laplacian sharpen'
                out = laplacianSharpen(S.img, 0.9);
            case 'Unsharp mask'
                out = highPassSharpen(S.img, ksize, 0.9);
            case 'Gaussian low-pass'
                out = frequencyFilter(S.img, 'lowpass', enhD0.Value, 24, 'gaussian');
            case 'Gaussian high-pass'
                out = frequencyFilter(S.img, 'highpass', enhD0.Value, 24, 'gaussian');
            case 'Gaussian band-pass'
                out = frequencyFilter(S.img, 'bandpass', enhD0.Value, 28, 'gaussian');
            otherwise
                out = frequencyFilter(asGray(S.img), 'lowpass', enhD0.Value, 24, 'ideal');
        end
        setStatus(['Enhancement: ', enhOp.Value]);
    end

    function out = runSegmentation()
        radius = max(1, round(segRadius.Value));
        switch segOp.Value
            case 'Sobel'
                [~, out] = sobelEdge(S.img, 0.18);
            case 'Prewitt'
                [~, out] = prewittEdge(S.img, 0.18);
            case 'Canny'
                [~, out] = cannyEdge(S.img, 1.4, 0.04, 0.14);
            case 'Compare edges'
                out = compareEdgeDetectors(S.img);
            case 'Otsu'
                [level, out] = otsuThreshold(S.img);
                setStatus(sprintf('Otsu threshold t = %d', level));
                return;
            case 'Region growing'
                out = regionGrowing(S.img, [seedRow.Value, seedCol.Value], segTol.Value);
            case 'Color red'
                out = colorSegmentation(S.img, 'red');
            case 'Color blue'
                out = colorSegmentation(S.img, 'blue');
            case 'Color green'
                out = colorSegmentation(S.img, 'green');
            case 'Color skin'
                out = colorSegmentation(S.img, 'skin');
            case 'Dilate'
                [~, base] = otsuThreshold(S.img);
                out = morphOperation(base, 'dilate', radius, 'disk');
            case 'Erode'
                [~, base] = otsuThreshold(S.img);
                out = morphOperation(base, 'erode', radius, 'disk');
            case 'Open'
                [~, base] = otsuThreshold(S.img);
                out = morphOperation(base, 'open', radius, 'disk');
            case 'Close'
                [~, base] = otsuThreshold(S.img);
                out = morphOperation(base, 'close', radius, 'disk');
            otherwise
                [~, base] = otsuThreshold(S.img);
                out = shapeSegmentation(base);
        end
        setStatus(['Segmentation: ', segOp.Value]);
    end

    function out = runGeometry()
        method = geoMethod.Value;
        switch geoOp.Value
            case 'Translate'
                out = translateImage(S.img, geoTx.Value, geoTy.Value, method);
            case 'Scale'
                out = scaleImage(S.img, geoScale.Value, method, true);
            case 'Rotate'
                out = rotateImage(S.img, geoAngle.Value, method, 'reverse', false);
            case 'Forward rotate'
                out = rotateImage(asGray(S.img), geoAngle.Value, method, 'forward', false);
            case 'Shear'
                out = affineWarp(S.img, shearMatrix(size(S.img, 2), size(S.img, 1), 0.28), method);
            case 'Barrel distort'
                out = radialDistortion(S.img, geoK.Value, 0, 'distort', method);
            case 'Undistort'
                out = radialDistortion(S.img, geoK.Value, 0, 'correct', method);
            otherwise
                if isempty(S.moving)
                    error('Load a moving image first.');
                end
                [out, reg] = registerImages(S.img, S.moving, method);
                setStatus(sprintf('Register: %.1f deg, MI %.2f -> %.2f, inliers %d', ...
                    reg.angleDeg, reg.miBefore, reg.miAfter, reg.inliers));
                return;
        end
        setStatus(['Geometry: ', geoOp.Value]);
    end

    function onCamera(~, ~)
        stopCamera();
        try
            S.cam = webcam;
        catch
            setStatus('No webcam support package. Load an image instead.');
            return;
        end
        S.timer = timer('ExecutionMode', 'fixedSpacing', 'Period', 0.2, ...
            'TimerFcn', @grabFrame);
        start(S.timer);
        setStatus('Camera running. Close the window to stop.');
    end

    function grabFrame(~, ~)
        if isempty(S.cam)
            return;
        end
        frame = toDouble(snapshot(S.cam));
        S.img = frame;
        try
            S.result = applyARFilter(frame, arFilter.Value, 'bilinear', false, arScale.Value);
        catch
            S.result = frame;
        end
        showBoth();
    end

    function onClose(~, ~)
        stopCamera();
        delete(fig);
    end

    function stopCamera()
        if ~isempty(S.timer) && isvalid(S.timer)
            stop(S.timer);
            delete(S.timer);
        end
        S.timer = [];
        S.cam = [];
    end

    function showBoth()
        paint(ax1, S.img, 'Original');
        paint(ax2, S.result, 'Result');
    end

    function setStatus(text)
        status.Text = text;
    end
end

function styleAxes(ax, name)
ax.XTick = [];
ax.YTick = [];
title(ax, name);
end

function paint(ax, img, name)
if isempty(img)
    cla(ax);
    title(ax, name);
    return;
end
shown = toUint8Image(img);
if size(shown, 3) == 1
    imagesc(ax, shown);
    colormap(ax, gray(256));
else
    image(ax, shown);
end
axis(ax, 'image');
ax.XTick = [];
ax.YTick = [];
title(ax, name);
end

function k = oddFrom(value)
k = max(3, round(value));
if mod(k, 2) == 0
    k = k + 1;
end
end

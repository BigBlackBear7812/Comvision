function selfTest()
%SELFTEST  Checks that do not need the GUI. Student 3.
%   Run after addpath(genpath(pwd)) from the toolbox folder.

root = fileparts(mfilename('fullpath'));
addpath(genpath(root));
failed = 0;
failed = failed + checkRotation();
failed = failed + checkOtsu();
failed = failed + checkEqualize();
failed = failed + checkMedian();
failed = failed + checkFace();
if failed == 0
    fprintf('selfTest: all checks passed.\n');
else
    fprintf('selfTest: %d check(s) failed.\n', failed);
end
end

function n = checkRotation()
img = zeros(21, 21);
img(11, 19) = 1;
rot = rotateImage(img, 90, 'nearest');
[y, x] = find(rot > 0.5);
ok = numel(x) == 1 && abs(x - 11) <= 1 && y <= 4;
n = report('rotation +90 CCW', ok);
end

function n = checkOtsu()
img = zeros(40, 80);
img(:, 41:end) = 1;
[level, mask] = otsuThreshold(img);
ok = level > 20 && level < 230 && abs(mean(mask(:, 1)) - 0) < 1e-6 && mean(mask(:, end)) > 0.9;
n = report('Otsu separates a two-tone image', ok);
end

function n = checkEqualize()
img = zeros(30, 30);
img(1:15, :) = 0.15;
img(16:end, :) = 0.45;
out = histogramEqualize(img);
ok = std(out(:)) > std(img(:));
n = report('histogram equalization spreads levels', ok);
end

function n = checkMedian()
rng(1);
img = zeros(25, 25);
img(8:18, 8:18) = 0.7;
noisy = img;
picks = rand(size(img));
noisy(picks < 0.05) = 1;
noisy(picks >= 0.05 & picks < 0.10) = 0;
meanErr = mean((spatialMeanFilter(noisy, 3) - img) .^ 2);
medErr = mean((spatialMedianFilter(noisy, 3) - img) .^ 2);
n = report('median beats mean on salt-and-pepper', medErr < meanErr);
end

function n = checkFace()
root = fileparts(mfilename('fullpath'));
path = fullfile(root, 'samples', 'portrait.png');
if ~exist(path, 'file')
    fprintf('  skip  face landmarks (samples/portrait.png missing)\n');
    n = 0;
    return;
end
info = detectFaceRegions(imread(path));
ok = ~isempty(info.faces) && strcmp(info.faces(1).eyeSource, 'detected');
if ok
    err = hypot(info.faces(1).leftEye(1) - 272, info.faces(1).leftEye(2) - 347);
    ok = err < 8;
end
n = report('portrait eye landmarks', ok);
end

function n = report(name, ok)
if ok
    fprintf('  pass  %s\n', name);
    n = 0;
else
    fprintf('  FAIL  %s\n', name);
    n = 1;
end
end

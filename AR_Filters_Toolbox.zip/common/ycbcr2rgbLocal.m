function out = ycbcr2rgbLocal(img)
%YCBCR2RGBLOCAL  Inverse of rgb2ycbcrLocal.

Y = img(:, :, 1);
Cb = img(:, :, 2);
Cr = img(:, :, 3);
R = Y + 1.402 * (Cr - 0.5);
G = Y - 0.344136 * (Cb - 0.5) - 0.714136 * (Cr - 0.5);
B = Y + 1.772 * (Cb - 0.5);
out = min(max(cat(3, R, G, B), 0), 1);
end

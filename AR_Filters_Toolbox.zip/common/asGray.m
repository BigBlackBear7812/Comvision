function gray = asGray(img)
%ASGRAY  Luminance Y = 0.299 R + 0.587 G + 0.114 B.

img = toDouble(img);
if ndims(img) < 3 || size(img, 3) == 1
    gray = img(:, :, 1);
else
    gray = 0.299 * img(:, :, 1) + 0.587 * img(:, :, 2) + 0.114 * img(:, :, 3);
end
end

function out = applyPlane(img, fn)
%APPLYPLANE  Run a grayscale function on each channel.

if ndims(img) == 2 || size(img, 3) == 1
    out = fn(img(:, :, 1));
    return;
end
planes = cell(1, size(img, 3));
for c = 1:size(img, 3)
    planes{c} = fn(img(:, :, c));
end
out = cat(3, planes{:});
end

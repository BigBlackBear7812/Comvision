function out = toDouble(img)
%TODOUBLE  Scale an image to double precision in [0, 1].
%   Student 1 / shared utility. uint8 and uint16 are divided by their
%   full-scale value. A double image that is already in [0, 1] is kept.

if isa(img, 'uint8')
    out = double(img) / 255;
elseif isa(img, 'uint16')
    out = double(img) / 65535;
elseif islogical(img)
    out = double(img);
else
    out = double(img);
    if max(out(:)) > 1.5
        out = out / 255;
    end
end
out = min(max(out, 0), 1);
end

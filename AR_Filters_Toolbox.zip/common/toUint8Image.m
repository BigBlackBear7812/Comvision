function out = toUint8Image(img)
%TOUINT8IMAGE  Convert a [0, 1] or [0, 255] image to uint8.

img = double(img);
if max(img(:)) <= 1.5
    img = img * 255;
end
out = uint8(min(max(round(img), 0), 255));
end

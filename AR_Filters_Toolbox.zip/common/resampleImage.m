function out = resampleImage(img, mapX, mapY, method, border)
%RESAMPLEIMAGE  Reverse-map resampling. Student 3.
%   mapX, mapY are source column and row in 0-based pixel coordinates
%   (the same convention as the geometry module). method is
%   'nearest', 'bilinear', or 'bicubic'. border is 'constant' or 'replicate'.

if nargin < 4 || isempty(method), method = 'bilinear'; end
if nargin < 5 || isempty(border), border = 'constant'; end
img = toDouble(img);
if ndims(img) == 2
    out = resamplePlane(img, mapX, mapY, method, border);
    return;
end
planes = cell(1, size(img, 3));
for c = 1:size(img, 3)
    planes{c} = resamplePlane(img(:, :, c), mapX, mapY, method, border);
end
out = cat(3, planes{:});
end

function out = resamplePlane(plane, mapX, mapY, method, border)
[srcH, srcW] = size(plane);
[outH, outW] = size(mapX);
switch lower(method)
    case 'nearest'
        xi = round(mapX);
        yi = round(mapY);
        out = pull(plane, yi, xi, border, srcH, srcW);
    case 'bilinear'
        x0 = floor(mapX);
        y0 = floor(mapY);
        wx = mapX - x0;
        wy = mapY - y0;
        ia = pull(plane, y0, x0, border, srcH, srcW);
        ib = pull(plane, y0, x0 + 1, border, srcH, srcW);
        ic = pull(plane, y0 + 1, x0, border, srcH, srcW);
        id = pull(plane, y0 + 1, x0 + 1, border, srcH, srcW);
        out = ia .* (1 - wx) .* (1 - wy) + ib .* wx .* (1 - wy) ...
            + ic .* (1 - wx) .* wy + id .* wx .* wy;
    case 'bicubic'
        xInt = floor(mapX);
        yInt = floor(mapY);
        dx = mapX - xInt;
        dy = mapY - yInt;
        out = zeros(outH, outW);
        for j = -1:2
            wy = cubicWeight(dy - j);
            for i = -1:2
                wx = cubicWeight(dx - i);
                samp = pull(plane, yInt + j, xInt + i, border, srcH, srcW);
                out = out + samp .* wx .* wy;
            end
        end
        out = min(max(out, 0), 1);
    otherwise
        error('resampleImage:Method', 'Unknown method "%s".', method);
end
end

function values = pull(plane, yy, xx, border, srcH, srcW)
if strcmpi(border, 'replicate')
    xx = min(max(xx, 0), srcW - 1);
    yy = min(max(yy, 0), srcH - 1);
    values = plane(sub2ind([srcH, srcW], yy + 1, xx + 1));
else
    values = zeros(size(xx));
    good = xx >= 0 & xx <= srcW - 1 & yy >= 0 & yy <= srcH - 1;
    if any(good(:))
        values(good) = plane(sub2ind([srcH, srcW], yy(good) + 1, xx(good) + 1));
    end
end
end

function w = cubicWeight(t)
% Keys cubic, a = -0.5.
a = -0.5;
at = abs(t);
w = zeros(size(at));
m1 = at <= 1;
m2 = at > 1 & at < 2;
w(m1) = (a + 2) .* at(m1) .^ 3 - (a + 3) .* at(m1) .^ 2 + 1;
w(m2) = a .* at(m2) .^ 3 - 5 * a .* at(m2) .^ 2 + 8 * a .* at(m2) - 4 * a;
end

function out = rgb2ycbcrLocal(img)
%RGB2YCBCRLOCAL  RGB to YCbCr, all channels in [0, 1].
%   Written for the toolbox so it does not depend on the Image
%   Processing Toolbox. Student 1 uses Y for histogram work; Student 2
%   uses Cb and Cr for the skin gate inside face detection.

img = toDouble(img);
R = img(:, :, 1);
G = img(:, :, 2);
B = img(:, :, 3);
Y  =  0.299 * R + 0.587 * G + 0.114 * B;
Cb = -0.168736 * R - 0.331264 * G + 0.5 * B + 0.5;
Cr =  0.5 * R - 0.418688 * G - 0.081312 * B + 0.5;
out = cat(3, Y, Cb, Cr);
end

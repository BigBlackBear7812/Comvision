function se = diskSE(radius)
%DISKSE  Round structuring element of the given radius.

radius = max(0, round(radius));
[xx, yy] = meshgrid(-radius:radius, -radius:radius);
se = (xx .^ 2 + yy .^ 2) <= radius ^ 2;
end

function h = gaussKernel(sigma)
%GAUSSKERNEL  Normalized Gaussian, radius = ceil(3 sigma).

sigma = max(double(sigma), 0.4);
rad = max(1, ceil(3 * sigma));
ax = -rad:rad;
[xx, yy] = meshgrid(ax, ax);
h = exp(-(xx .^ 2 + yy .^ 2) / (2 * sigma ^ 2));
h = h / sum(h(:));
end

function info = detectFaceRegions(img)
%DETECTFACEREGIONS  Skin blob, face span, then two dark eye blobs.
%   Student 2 built the mask and the eye search. Coordinates in the
%   returned struct are 0-based (column, row), matching the geometry module.
%   If the eyes are not found, the landmarks fall back to face proportions.

src = toDouble(img);
gray = asGray(src);
mask = skinMask(src);
[labels, count] = connectedComponents(mask);
faces = struct('bbox', {}, 'leftEye', {}, 'rightEye', {}, 'nose', {}, ...
    'mouth', {}, 'angle', {}, 'eyeDist', {}, 'eyeSource', {});
info = struct('faces', faces, 'skin', mask);
if count == 0
    return;
end
areas = zeros(1, count);
for lab = 1:count
    areas(lab) = nnz(labels == lab);
end
[~, order] = sort(areas, 'descend');
[h, w] = size(gray);
for n = 1:min(3, count)
    lab = order(n);
    comp = labels == lab;
    if areas(lab) < 0.01 * h * w
        continue;
    end
    span = zeros(h, 1);
    for r = 1:h
        xs = find(comp(r, :));
        if ~isempty(xs)
            span(r) = xs(end) - xs(1) + 1;
        end
    end
    if max(span) < 8
        continue;
    end
    rows = find(span >= 0.58 * max(span));
    if isempty(rows)
        continue;
    end
    splits = find(diff(rows) > 1);
    bandStarts = [1; splits + 1];
    bandEnds = [splits; numel(rows)];
    bestLen = -1;
    band = rows;
    for b = 1:numel(bandStarts)
        this = rows(bandStarts(b):bandEnds(b));
        if numel(this) > bestLen
            bestLen = numel(this);
            band = this;
        end
    end
    y0 = band(1);
    y1 = band(end);
    xs = find(any(comp(y0:y1, :), 1));
    if isempty(xs)
        continue;
    end
    x0 = xs(1);
    x1 = xs(end);
    bw = x1 - x0 + 1;
    bh = y1 - y0 + 1;
    if bh < 20 || bw < 20
        continue;
    end
    aspect = bh / bw;
    if aspect < 0.7 || aspect > 2.4
        continue;
    end
    sub = gray(y0:y1, x0:x1);
    eyes = findEyes(sub);
    if isempty(eyes)
        left = [x0 - 1 + 0.32 * bw, y0 - 1 + 0.40 * bh];
        right = [x0 - 1 + 0.68 * bw, y0 - 1 + 0.40 * bh];
        source = 'geometric';
    else
        left = [x0 - 1 + eyes(1, 1), y0 - 1 + eyes(1, 2)];
        right = [x0 - 1 + eyes(2, 1), y0 - 1 + eyes(2, 2)];
        source = 'detected';
    end
    ang = atan2(right(2) - left(2), right(1) - left(1));
    direction = [cos(ang + pi / 2), sin(ang + pi / 2)];
    eyeMid = (left + right) / 2;
    eyeDist = hypot(right(1) - left(1), right(2) - left(2)) + 1e-6;
    nose = eyeMid + direction * (0.38 * eyeDist);
    mouth = eyeMid + direction * (0.85 * eyeDist);
    faces(end + 1) = struct( ... %#ok<AGROW>
        'bbox', [x0 - 1, y0 - 1, bw, bh], ...
        'leftEye', left, 'rightEye', right, 'nose', nose, 'mouth', mouth, ...
        'angle', ang, 'eyeDist', eyeDist, 'eyeSource', source);
end
info.faces = faces;
info.skin = mask;
end

function eyes = findEyes(faceGray)
eyes = [];
[h, w] = size(faceGray);
yA = max(1, round(0.28 * h));
yB = max(yA, round(0.58 * h));
band = faceGray(yA:yB, :);
if isempty(band)
    return;
end
level = percentileLocal(band, 0.22);
dark = band <= level;
dark = morphOperation(dark, 'open', 1, 'disk');
[labels, count] = connectedComponents(dark);
cands = zeros(0, 3);
for lab = 1:count
    comp = labels == lab;
    area = nnz(comp);
    if area < 12 || area > 0.08 * h * w
        continue;
    end
    [ys, xs] = find(comp);
    cands(end + 1, :) = [area, mean(xs), mean(ys) + yA - 1]; %#ok<AGROW>
end
if size(cands, 1) < 2
    return;
end
[~, order] = sort(cands(:, 1), 'descend');
cands = cands(order, :);
limit = min(6, size(cands, 1));
for i = 1:limit
    for j = i + 1:limit
        x1 = cands(i, 2); y1 = cands(i, 3);
        x2 = cands(j, 2); y2 = cands(j, 3);
        dx = abs(x1 - x2);
        dy = abs(y1 - y2);
        if dx >= 0.18 * w && dx <= 0.70 * w && dy <= 0.18 * h
            if x1 < x2
                eyes = [x1 - 1, y1 - 1; x2 - 1, y2 - 1];
            else
                eyes = [x2 - 1, y2 - 1; x1 - 1, y1 - 1];
            end
            return;
        end
    end
end
end

function value = percentileLocal(img, fraction)
values = sort(img(:));
idx = max(1, min(numel(values), round(fraction * numel(values))));
value = values(idx);
end

function out = backgroundBlur(img, info)
%BACKGROUNDBLUR  Keep the person, low-pass the rest. Student 1 + 2.
%   The foreground is the skin mask grown over the body rectangle,
%   then closed. The blur is Student 1's Gaussian frequency filter.

src = toDouble(img);
if nargin < 2 || isempty(info)
    info = detectFaceRegions(src);
end
[h, w, ~] = size(src);
fg = info.skin;
for k = 1:numel(info.faces)
    box = info.faces(k).bbox;
    x = box(1); y = box(2); bw = box(3); bh = box(4);
    x0 = max(1, floor(x - 0.25 * bw) + 1);
    x1 = min(w, ceil(x + 1.25 * bw));
    y0 = max(1, floor(y - 0.15 * bh) + 1);
    y1 = min(h, ceil(y + 2.4 * bh));
    fg(y0:y1, x0:x1) = true;
end
fg = morphOperation(fg, 'close', 12, 'disk');
blur = frequencyFilter(src, 'lowpass', 18, 20, 'gaussian');
alpha = filter2(gaussKernel(3), double(fg), 'same');
alpha = repmat(alpha, 1, 1, size(src, 3));
out = min(max(src .* alpha + blur .* (1 - alpha), 0), 1);
end

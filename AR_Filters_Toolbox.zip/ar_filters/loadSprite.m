function sprite = loadSprite(fileName)
%LOADSPRITE  Read an RGBA PNG from the assets folder. Student 3.

root = fileparts(fileparts(mfilename('fullpath')));
path = fullfile(root, 'assets', fileName);
[color, ~, alpha] = imread(path);
color = toDouble(color);
if isempty(alpha)
    alpha = ones(size(color, 1), size(color, 2));
else
    alpha = toDouble(alpha);
end
if ndims(color) == 2
    color = repmat(color, 1, 1, 3);
end
sprite = cat(3, color(:, :, 1:3), alpha);
end

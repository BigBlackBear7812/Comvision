function out = colorPop(img, target)
%COLORPOP  Keep one HSV range and remove saturation everywhere else.
%   Student 2's color segmentation decides which pixels stay in color.

if nargin < 2, target = 'red'; end
src = toDouble(img);
mask = colorSegmentation(src, target);
alpha = filter2(gaussKernel(0.8), double(mask), 'same');
alpha = repmat(alpha, 1, 1, 3);
hsv = rgb2hsv(src);
hsv(:, :, 2) = 0;
grayish = hsv2rgb(hsv);
out = min(max(src .* alpha + grayish .* (1 - alpha), 0), 1);
end

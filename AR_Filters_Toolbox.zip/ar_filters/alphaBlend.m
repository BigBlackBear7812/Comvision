function out = alphaBlend(background, sprite, left, top)
%ALPHABLEND  Porter-Duff "over" for an RGBA sprite. Student 3.
%   left and top are 0-based coordinates of the sprite's top-left pixel.
%   out = sprite * alpha + background * (1 - alpha).

bg = toDouble(background);
if ndims(bg) == 2 || size(bg, 3) == 1
    bg = repmat(bg(:, :, 1), 1, 1, 3);
end
sp = double(sprite);
if max(sp(:)) > 1.5
    sp = sp / 255;
end
if size(sp, 3) == 3
    sp = cat(3, sp, ones(size(sp, 1), size(sp, 2)));
end
[h, w, ~] = size(bg);
sh = size(sp, 1);
sw = size(sp, 2);
x0 = round(left);
y0 = round(top);
x1 = x0 + sw;
y1 = y0 + sh;
bx0 = max(0, x0);
by0 = max(0, y0);
bx1 = min(w, x1);
by1 = min(h, y1);
out = bg;
if bx0 >= bx1 || by0 >= by1
    return;
end
fx0 = bx0 - x0;
fy0 = by0 - y0;
fx1 = fx0 + (bx1 - bx0);
fy1 = fy0 + (by1 - by0);
crop = sp(fy0 + 1:fy1, fx0 + 1:fx1, :);
alpha = crop(:, :, 4);
roi = out(by0 + 1:by1, bx0 + 1:bx1, :);
blended = crop(:, :, 1:3) .* alpha + roi .* (1 - alpha);
out(by0 + 1:by1, bx0 + 1:bx1, :) = min(max(blended, 0), 1);
end

function out = drawLandmarks(img, info)
%DRAWLANDMARKS  Box and points for the GUI preview. Student 3.
%   Landmarks are 0-based. This only marks pixels; it is not a detector.

out = toDouble(img);
if ndims(out) == 2
    out = repmat(out, 1, 1, 3);
end
[h, w, ~] = size(out);
for k = 1:numel(info.faces)
    face = info.faces(k);
    out = stampRect(out, face.bbox, [1, 0.25, 0.25]);
    out = stampPoint(out, face.leftEye, [0.15, 0.35, 1]);
    out = stampPoint(out, face.rightEye, [0.15, 0.35, 1]);
    out = stampPoint(out, face.nose, [0.15, 0.7, 0.15]);
    out = stampPoint(out, face.mouth, [0.9, 0.55, 0.1]);
end
out = min(max(out, 0), 1);
end

function out = stampRect(out, bbox, color)
[h, w, ~] = size(out);
x0 = max(1, round(bbox(1)) + 1);
y0 = max(1, round(bbox(2)) + 1);
x1 = min(w, round(bbox(1) + bbox(3)));
y1 = min(h, round(bbox(2) + bbox(4)));
if x0 > x1 || y0 > y1
    return;
end
t = 2;
out(y0:min(h, y0 + t), x0:x1, 1) = color(1);
out(y0:min(h, y0 + t), x0:x1, 2) = color(2);
out(y0:min(h, y0 + t), x0:x1, 3) = color(3);
out(max(1, y1 - t):y1, x0:x1, 1) = color(1);
out(max(1, y1 - t):y1, x0:x1, 2) = color(2);
out(max(1, y1 - t):y1, x0:x1, 3) = color(3);
out(y0:y1, x0:min(w, x0 + t), 1) = color(1);
out(y0:y1, x0:min(w, x0 + t), 2) = color(2);
out(y0:y1, x0:min(w, x0 + t), 3) = color(3);
out(y0:y1, max(1, x1 - t):x1, 1) = color(1);
out(y0:y1, max(1, x1 - t):x1, 2) = color(2);
out(y0:y1, max(1, x1 - t):x1, 3) = color(3);
end

function out = stampPoint(out, xy, color)
[h, w, ~] = size(out);
x = round(xy(1)) + 1;
y = round(xy(2)) + 1;
for dy = -3:3
    for dx = -3:3
        yy = y + dy;
        xx = x + dx;
        if yy >= 1 && yy <= h && xx >= 1 && xx <= w
            out(yy, xx, :) = reshape(color, 1, 1, 3);
        end
    end
end
end

function out = placeSprite(background, sprite, destXY, widthPx, angleDeg, anchorNorm, method)
%PLACESPRITE  Scale, rotate, and blend a filter onto a landmark. Student 3.
%   destXY is 0-based [x, y]. Positive angleDeg is counterclockwise.
%   Scaling and rotation both go through resampleImage.

if nargin < 7 || isempty(method), method = 'bilinear'; end
sp = double(sprite);
if max(sp(:)) > 1.5
    sp = sp / 255;
end
srcH = size(sp, 1);
srcW = size(sp, 2);
newW = max(1, round(widthPx));
newH = max(1, round(srcH * (newW / srcW)));
planes = cell(1, size(sp, 3));
for c = 1:size(sp, 3)
    planes{c} = resizeImage(sp(:, :, c), newH, newW, method);
end
scaled = cat(3, planes{:});
[rotated, center] = rotateRGBA(scaled, angleDeg, method);
anchor = [anchorNorm(1) * (size(scaled, 2) - 1), anchorNorm(2) * (size(scaled, 1) - 1)];
[c, s] = terms(angleDeg);
rel = anchor - [(size(scaled, 2) - 1) / 2, (size(scaled, 1) - 1) / 2];
movedX = c * rel(1) + s * rel(2);
movedY = -s * rel(1) + c * rel(2);
moved = [movedX, movedY] + center;
left = destXY(1) - moved(1);
top = destXY(2) - moved(2);
out = alphaBlend(background, rotated, left, top);
end

function [out, center] = rotateRGBA(sprite, angleDeg, method)
[h, w, ch] = size(sprite);
cx = (w - 1) / 2;
cy = (h - 1) / 2;
[c, s] = terms(angleDeg);
corners = [0, 0; w - 1, 0; w - 1, h - 1; 0, h - 1];
rel = corners - [cx, cy];
rot = [c * rel(:, 1) + s * rel(:, 2), -s * rel(:, 1) + c * rel(:, 2)];
minXY = min(rot, [], 1);
maxXY = max(rot, [], 1);
outW = ceil(maxXY(1) - minXY(1) + 1);
outH = ceil(maxXY(2) - minXY(2) + 1);
destCx = -minXY(1);
destCy = -minXY(2);
[xx, yy] = meshgrid(0:outW - 1, 0:outH - 1);
dx = xx - destCx;
dy = yy - destCy;
srcX = cx + c * dx - s * dy;
srcY = cy + s * dx + c * dy;
planes = cell(1, ch);
for k = 1:ch
    planes{k} = resampleImage(sprite(:, :, k), srcX, srcY, method, 'constant');
end
out = cat(3, planes{:});
center = [destCx, destCy];
end

function [c, s] = terms(angleDeg)
a = deg2rad(angleDeg);
c = cos(a);
s = sin(a);
end

function spec = filterCatalog(name)
%FILTERCATALOG  Sprite file, anchor, and size relative to the eye distance.
%   Student 3. anchorNorm is the point of the PNG that sits on the landmark.
%   y grows downward, so a hat brim is near the bottom of its PNG.

catalog = struct();
catalog.glasses = pack('glasses.png', 'eyes', 2.55, [0.50, 0.50]);
catalog.mustache = pack('mustache.png', 'nose', 1.55, [0.50, 0.18]);
catalog.hat = pack('hat.png', 'forehead', 2.05, [0.50, 0.90]);
catalog.party = pack('party.png', 'forehead', 1.35, [0.50, 0.92]);
catalog.dog = pack('dog_ears.png', 'ears', 2.35, [0.50, 0.78]);
catalog.nose = pack('dog_nose.png', 'nose', 0.85, [0.50, 0.55]);
if nargin < 1 || isempty(name)
    spec = catalog;
else
    spec = catalog.(name);
end
end

function s = pack(file, anchor, width, anchorNorm)
s = struct('file', file, 'anchor', anchor, 'width', width, 'anchorNorm', anchorNorm);
end

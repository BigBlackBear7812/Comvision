function [out, info] = applyARFilter(img, name, method, enhance, scale)
%APPLYARFILTER  Topic 13: place a virtual filter on a detected face.
%   Student 3 integrated the three modules:
%     Student 1  histogram equalization, median, frequency blur
%     Student 2  skin mask, face and eye landmarks, HSV color pop
%     Student 3  resize, rotate, and alpha blend of the sprite
%
%   name: glasses, mustache, hat, party, dog, combo, beauty, bgblur, colorpop

if nargin < 2 || isempty(name), name = 'glasses'; end
if nargin < 3 || isempty(method), method = 'bilinear'; end
if nargin < 4 || isempty(enhance), enhance = false; end
if nargin < 5 || isempty(scale), scale = 1; end
src = toDouble(img);
info = detectFaceRegions(src);
if enhance
    out = histogramEqualize(src);
else
    out = src;
end
name = lower(name);
if strcmp(name, 'beauty')
    out = beautyFilter(src, info);
    return;
end
if strcmp(name, 'bgblur')
    out = backgroundBlur(src, info);
    return;
end
if strcmp(name, 'colorpop')
    out = colorPop(src, 'red');
    return;
end
if isempty(info.faces)
    return;
end
if strcmp(name, 'combo')
    sequence = {'hat', 'glasses', 'mustache'};
elseif strcmp(name, 'dog')
    sequence = {'dog', 'nose'};
else
    sequence = {name};
end
face = info.faces(1);
% atan2 in y-down is clockwise-positive. Rotation here is counterclockwise.
angle = -rad2deg(face.angle);
eyeMid = (face.leftEye + face.rightEye) / 2;
direction = [cos(face.angle + pi / 2), sin(face.angle + pi / 2)];
for k = 1:numel(sequence)
    spec = filterCatalog(sequence{k});
    switch spec.anchor
        case 'eyes'
            dest = eyeMid + direction * (0.02 * face.eyeDist);
            width = spec.width * face.eyeDist * scale;
        case 'nose'
            dest = face.nose;
            width = spec.width * face.eyeDist * scale;
        case 'forehead'
            dest = eyeMid - direction * (1.05 * face.eyeDist);
            width = spec.width * face.eyeDist * scale;
        otherwise
            dest = eyeMid - direction * (1.15 * face.eyeDist);
            width = spec.width * face.eyeDist * scale;
    end
    sprite = loadSprite(spec.file);
    out = placeSprite(out, sprite, dest, width, angle, spec.anchorNorm, method);
end
end

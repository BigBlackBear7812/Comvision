function out = beautyFilter(img, info)
%BEAUTYFILTER  Median smooth on skin, away from Sobel edges. Student 1 + 2.
%   Flat skin loses salt-and-pepper noise. Eyes, mouth, and hair stay sharp.

src = toDouble(img);
if nargin < 2 || isempty(info)
    info = detectFaceRegions(src);
end
smooth = spatialMedianFilter(src, 5);
[mag, ~] = sobelEdge(src, 0.12);
edges = mag > 0.18;
alpha = info.skin & ~edges;
alphaF = filter2(gaussKernel(1.2), double(alpha), 'same');
alphaF = repmat(alphaF, 1, 1, size(src, 3));
mixed = src .* (1 - alphaF) + smooth .* alphaF;
lifted = grayLevelTransform(mixed, 'both', 0.02, 1.08);
out = min(max(src .* (1 - alphaF) + lifted .* alphaF, 0), 1);
end

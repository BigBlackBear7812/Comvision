# Reference implementation of the toolbox algorithms.
# The MATLAB files under module1_enhancement, module2_segmentation,
# module3_geometry and ar_filters follow these same formulas.
# This runner exists so sample figures can be produced on a PC without MATLAB.

from __future__ import annotations

import numpy as np
from scipy import ndimage


def to_float(img):
    img = np.asarray(img)
    if img.dtype == np.bool_:
        return img.astype(np.float64)
    img = img.astype(np.float64)
    if img.max(initial=0) > 1.5:
        img = img / 255.0
    return np.clip(img, 0.0, 1.0)


def to_uint8(img):
    img = np.asarray(img, dtype=np.float64)
    if img.max(initial=0) <= 1.5:
        img = img * 255.0
    return np.clip(np.rint(img), 0, 255).astype(np.uint8)


def as_gray(img):
    img = to_float(img)
    if img.ndim == 2:
        return img
    return 0.299 * img[:, :, 0] + 0.587 * img[:, :, 1] + 0.114 * img[:, :, 2]


def rgb_to_ycbcr(img):
    img = to_float(img)
    r, g, b = img[:, :, 0], img[:, :, 1], img[:, :, 2]
    y = 0.299 * r + 0.587 * g + 0.114 * b
    cb = -0.168736 * r - 0.331264 * g + 0.5 * b + 0.5
    cr = 0.5 * r - 0.418688 * g - 0.081312 * b + 0.5
    return np.dstack([y, cb, cr])


def ycbcr_to_rgb(img):
    y, cb, cr = img[:, :, 0], img[:, :, 1], img[:, :, 2]
    r = y + 1.402 * (cr - 0.5)
    g = y - 0.344136 * (cb - 0.5) - 0.714136 * (cr - 0.5)
    b = y + 1.772 * (cb - 0.5)
    return np.clip(np.dstack([r, g, b]), 0.0, 1.0)


def rgb_to_hsv(img):
    img = to_float(img)
    r, g, b = img[:, :, 0], img[:, :, 1], img[:, :, 2]
    mx = np.maximum(np.maximum(r, g), b)
    mn = np.minimum(np.minimum(r, g), b)
    df = mx - mn
    h = np.zeros_like(mx)
    m = df > 1e-8
    mr = m & (mx == r)
    mg = m & (mx == g)
    mb = m & (mx == b)
    h[mr] = np.mod((g[mr] - b[mr]) / df[mr], 6.0)
    h[mg] = (b[mg] - r[mg]) / df[mg] + 2.0
    h[mb] = (r[mb] - g[mb]) / df[mb] + 4.0
    h = np.mod(h, 6.0) / 6.0
    s = np.zeros_like(mx)
    s[mx > 1e-8] = df[mx > 1e-8] / mx[mx > 1e-8]
    return np.dstack([h, s, mx])


def hsv_to_rgb(img):
    h, s, v = img[:, :, 0], img[:, :, 1], img[:, :, 2]
    h6 = h * 6.0
    i = np.floor(h6).astype(np.int32)
    f = h6 - i
    p = v * (1.0 - s)
    q = v * (1.0 - f * s)
    t = v * (1.0 - (1.0 - f) * s)
    i = np.mod(i, 6)
    out = np.zeros(img.shape, dtype=np.float64)
    for k, (rk, gk, bk) in enumerate(
        ((v, t, p), (q, v, p), (p, v, t), (p, q, v), (t, p, v), (v, p, q))
    ):
        m = i == k
        out[m, 0] = rk[m]
        out[m, 1] = gk[m]
        out[m, 2] = bk[m]
    return np.clip(out, 0.0, 1.0)


def _cdf_map(values):
    hist = np.bincount(values.ravel(), minlength=256).astype(np.float64)
    cdf = np.cumsum(hist)
    cdf_min = cdf[cdf > 0][0]
    total = values.size
    mapping = np.rint((cdf - cdf_min) / max(total - cdf_min, 1) * 255.0)
    return np.clip(mapping, 0, 255).astype(np.uint8)


def histogram_equalize(img):
    """Equalize luminance and keep chrominance for color images."""
    src = to_float(img)
    if src.ndim == 2:
        g = np.clip(np.rint(src * 255), 0, 255).astype(np.uint8)
        return _cdf_map(g)[g].astype(np.float64) / 255.0
    ycbcr = rgb_to_ycbcr(src)
    y8 = np.clip(np.rint(ycbcr[:, :, 0] * 255), 0, 255).astype(np.uint8)
    ycbcr[:, :, 0] = _cdf_map(y8)[y8].astype(np.float64) / 255.0
    return ycbcr_to_rgb(ycbcr)


def histogram_match(src, ref):
    src_f = to_float(src)
    ref_y = as_gray(ref)
    ref8 = np.clip(np.rint(ref_y * 255), 0, 255).astype(np.uint8)
    ref_cdf = np.cumsum(np.bincount(ref8.ravel(), minlength=256).astype(np.float64))
    ref_cdf = ref_cdf / ref_cdf[-1]

    def match_channel(ch):
        s8 = np.clip(np.rint(ch * 255), 0, 255).astype(np.uint8)
        s_cdf = np.cumsum(np.bincount(s8.ravel(), minlength=256).astype(np.float64))
        s_cdf = s_cdf / max(s_cdf[-1], 1)
        mapping = np.zeros(256, dtype=np.uint8)
        j = 0
        for i in range(256):
            while j < 255 and ref_cdf[j] < s_cdf[i]:
                j += 1
            mapping[i] = j
        return mapping[s8].astype(np.float64) / 255.0

    if src_f.ndim == 2:
        return match_channel(src_f)
    ycbcr = rgb_to_ycbcr(src_f)
    ycbcr[:, :, 0] = match_channel(ycbcr[:, :, 0])
    return ycbcr_to_rgb(ycbcr)


def gray_level_transform(img, mode="brightness", amount=0.0, contrast=1.0, gamma=1.0):
    src = to_float(img)
    if mode == "brightness":
        out = src + amount
    elif mode == "contrast":
        out = (src - 0.5) * contrast + 0.5
    elif mode == "both":
        out = (src - 0.5) * contrast + 0.5 + amount
    elif mode == "gamma":
        out = np.power(np.clip(src, 0, 1), gamma)
    elif mode == "negative":
        out = 1.0 - src
    elif mode == "log":
        c = 1.0 / np.log(1.0 + 1.0)
        out = c * np.log1p(src)
    else:
        raise ValueError(mode)
    return np.clip(out, 0.0, 1.0)


def gauss_kernel(sigma):
    rad = max(1, int(np.ceil(3 * sigma)))
    ax = np.arange(-rad, rad + 1, dtype=np.float64)
    xx, yy = np.meshgrid(ax, ax)
    h = np.exp(-(xx ** 2 + yy ** 2) / (2 * sigma ** 2))
    h /= h.sum()
    return h


def spatial_mean_filter(img, ksize=3):
    src = to_float(img)
    ksize = int(ksize) | 1
    kernel = np.ones((ksize, ksize), dtype=np.float64) / (ksize * ksize)
    if src.ndim == 2:
        return ndimage.convolve(src, kernel, mode="nearest")
    out = np.zeros_like(src)
    for c in range(src.shape[2]):
        out[:, :, c] = ndimage.convolve(src[:, :, c], kernel, mode="nearest")
    return out


def spatial_median_filter(img, ksize=3):
    src = to_float(img)
    ksize = int(ksize) | 1
    if src.ndim == 2:
        return ndimage.median_filter(src, size=ksize, mode="nearest")
    out = np.zeros_like(src)
    for c in range(src.shape[2]):
        out[:, :, c] = ndimage.median_filter(src[:, :, c], size=ksize, mode="nearest")
    return out


def laplacian_sharpen(img, amount=1.0):
    src = to_float(img)
    kernel = np.array([[0, 1, 0], [1, -4, 1], [0, 1, 0]], dtype=np.float64)

    def one(ch):
        lap = ndimage.convolve(ch, kernel, mode="nearest")
        return np.clip(ch - amount * lap, 0, 1)

    if src.ndim == 2:
        return one(src)
    return np.dstack([one(src[:, :, c]) for c in range(3)])


def high_pass_sharpen(img, ksize=5, amount=1.0):
    src = to_float(img)
    blur = spatial_mean_filter(src, ksize)
    return np.clip(src + amount * (src - blur), 0, 1)


def frequency_filter(img, kind="lowpass", d0=40.0, width=20.0, response="gaussian"):
    """Fourier filtering with zero-padding, as in Gonzalez and Woods."""

    def one(ch):
        f = ch.astype(np.float64)
        m, n = f.shape
        p, q = 2 * m, 2 * n
        fp = np.zeros((p, q), dtype=np.float64)
        fp[:m, :n] = f
        yy, xx = np.ogrid[0:p, 0:q]
        center = ((-1.0) ** (xx + yy)).astype(np.float64)
        fp = fp * center
        spec = np.fft.fft2(fp)
        dist = np.sqrt((yy - p / 2.0) ** 2 + (xx - q / 2.0) ** 2)
        if response == "ideal":
            if kind == "lowpass":
                transfer = (dist <= d0).astype(np.float64)
            elif kind == "highpass":
                transfer = (dist >= d0).astype(np.float64)
            elif kind == "bandpass":
                transfer = ((dist >= d0 - width / 2) & (dist <= d0 + width / 2)).astype(np.float64)
            else:
                transfer = 1.0 - ((dist >= d0 - width / 2) & (dist <= d0 + width / 2)).astype(np.float64)
        else:
            low = np.exp(-(dist ** 2) / (2.0 * (d0 ** 2) + 1e-8))
            if kind == "lowpass":
                transfer = low
            elif kind == "highpass":
                transfer = 1.0 - low
            else:
                ring = np.exp(-((dist ** 2 - d0 ** 2) ** 2) / ((dist * width) ** 2 + 1e-8))
                transfer = ring if kind == "bandpass" else 1.0 - ring
        rec = np.real(np.fft.ifft2(spec * transfer)) * center
        return np.clip(rec[:m, :n], 0.0, 1.0)

    src = to_float(img)
    if src.ndim == 2:
        return one(src)
    return np.dstack([one(src[:, :, c]) for c in range(src.shape[2])])


def _disk(radius):
    radius = int(radius)
    yy, xx = np.ogrid[-radius : radius + 1, -radius : radius + 1]
    return (xx * xx + yy * yy) <= radius * radius


def _gradient(img):
    gx_k = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=np.float64)
    gy_k = np.array([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=np.float64)
    gx = ndimage.convolve(img, gx_k, mode="nearest")
    gy = ndimage.convolve(img, gy_k, mode="nearest")
    mag = np.sqrt(gx ** 2 + gy ** 2)
    return gx, gy, mag


def sobel_edge(img, threshold=0.15):
    mag = _gradient(as_gray(img))[2]
    mag = mag / (mag.max() + 1e-12)
    return mag, mag >= threshold


def prewitt_edge(img, threshold=0.15):
    gray = as_gray(img)
    gx_k = np.array([[-1, 0, 1], [-1, 0, 1], [-1, 0, 1]], dtype=np.float64)
    gy_k = np.array([[-1, -1, -1], [0, 0, 0], [1, 1, 1]], dtype=np.float64)
    gx = ndimage.convolve(gray, gx_k, mode="nearest")
    gy = ndimage.convolve(gray, gy_k, mode="nearest")
    mag = np.sqrt(gx ** 2 + gy ** 2)
    mag = mag / (mag.max() + 1e-12)
    return mag, mag >= threshold


def canny_edge(img, sigma=1.2, t_low=0.08, t_high=0.22):
    gray = as_gray(img)
    smooth = ndimage.convolve(gray, gauss_kernel(sigma), mode="nearest")
    gx, gy, mag = _gradient(smooth)
    mag_n = mag / (mag.max() + 1e-12)
    angle = np.rad2deg(np.arctan2(gy, gx)) % 180.0
    padded = np.pad(mag_n, 1, mode="constant")
    center = padded[1:-1, 1:-1]
    east = padded[1:-1, 2:]
    west = padded[1:-1, :-2]
    north = padded[:-2, 1:-1]
    south = padded[2:, 1:-1]
    northeast = padded[:-2, 2:]
    northwest = padded[:-2, :-2]
    southeast = padded[2:, 2:]
    southwest = padded[2:, :-2]
    horiz = (angle < 22.5) | (angle >= 157.5)
    diag = (angle >= 22.5) & (angle < 67.5)
    vert = (angle >= 67.5) & (angle < 112.5)
    back = (angle >= 112.5) & (angle < 157.5)
    n1 = np.zeros_like(center)
    n2 = np.zeros_like(center)
    n1[horiz], n2[horiz] = east[horiz], west[horiz]
    n1[diag], n2[diag] = northeast[diag], southwest[diag]
    n1[vert], n2[vert] = north[vert], south[vert]
    n1[back], n2[back] = northwest[back], southeast[back]
    nms = np.where((center >= n1) & (center >= n2), mag_n, 0.0)
    strong = nms >= t_high
    weak = nms >= t_low
    labels, nlab = ndimage.label(weak, structure=np.ones((3, 3)))
    keep = np.zeros(nlab + 1, dtype=bool)
    if nlab:
        touched = np.unique(labels[strong])
        keep[touched] = True
        keep[0] = False
    edges = keep[labels]
    return nms, edges


def compare_edges(img):
    s = sobel_edge(img)[1]
    p = prewitt_edge(img)[1]
    c = canny_edge(img)[1]
    return s, p, c


def otsu_threshold(img):
    gray = as_gray(img)
    g8 = np.clip(np.rint(gray * 255), 0, 255).astype(np.uint8)
    hist = np.bincount(g8.ravel(), minlength=256).astype(np.float64)
    prob = hist / hist.sum()
    omega = np.cumsum(prob)
    mu = np.cumsum(prob * np.arange(256))
    mu_t = mu[-1]
    denom = omega * (1.0 - omega)
    sigma_b = np.zeros(256)
    valid = denom > 1e-12
    sigma_b[valid] = (mu_t * omega[valid] - mu[valid]) ** 2 / denom[valid]
    peak = float(sigma_b.max())
    if peak <= 0:
        level = 128
    else:
        # Two-tone pictures make every separating threshold equally good.
        # The middle of that plateau is the stable choice.
        candidates = np.flatnonzero(sigma_b >= peak * 0.999)
        level = int(np.round(np.median(candidates)))
    mask = g8 >= level
    return level, mask, gray


def region_growing(img, seed, tol=0.12):
    src = to_float(img)
    h, w = src.shape[:2]
    r = int(np.clip(seed[0], 0, h - 1))
    c = int(np.clip(seed[1], 0, w - 1))
    if src.ndim == 3:
        diff = np.sqrt(np.sum((src - src[r, c]) ** 2, axis=2))
    else:
        diff = np.abs(src - src[r, c])
    candidate = diff <= tol
    mask = np.zeros((h, w), dtype=bool)
    mask[r, c] = True
    se = np.ones((3, 3), dtype=bool)
    prev = -1
    while int(mask.sum()) != prev:
        prev = int(mask.sum())
        grown = ndimage.binary_dilation(mask, structure=se)
        mask = grown & candidate
        mask[r, c] = True
    return mask


def color_segmentation(img, target="red"):
    src = to_float(img)
    if target == "skin":
        return skin_mask(src)
    hsv = rgb_to_hsv(src)
    h, s, v = hsv[:, :, 0], hsv[:, :, 1], hsv[:, :, 2]
    if target == "red":
        hue = (h <= 0.05) | (h >= 0.95)
    elif target == "yellow":
        hue = (h >= 0.10) & (h <= 0.18)
    elif target == "green":
        hue = (h >= 0.22) & (h <= 0.45)
    elif target == "blue":
        hue = (h >= 0.52) & (h <= 0.72)
    else:
        raise ValueError(target)
    mask = hue & (s >= 0.35) & (v >= 0.20)
    mask = morph_operation(mask.astype(np.uint8), "open", 1, "disk").astype(bool)
    mask = morph_operation(mask.astype(np.uint8), "close", 2, "disk").astype(bool)
    return mask


def morph_operation(img, op="dilate", radius=2, shape="disk"):
    se = _disk(radius) if shape == "disk" else np.ones((2 * radius + 1, 2 * radius + 1), dtype=bool)
    arr = np.asarray(img)
    binary = arr.dtype == np.bool_ or (np.unique(arr).size <= 2 and arr.max() <= 1)
    if binary:
        bw = arr.astype(bool)
        if op == "dilate":
            return ndimage.binary_dilation(bw, structure=se)
        if op == "erode":
            return ndimage.binary_erosion(bw, structure=se)
        if op == "open":
            return ndimage.binary_opening(bw, structure=se)
        if op == "close":
            return ndimage.binary_closing(bw, structure=se)
        raise ValueError(op)
    src = to_float(arr)
    if src.ndim == 3:
        return np.dstack([morph_operation(src[:, :, c], op, radius, shape) for c in range(3)])
    if op == "dilate":
        return ndimage.grey_dilation(src, footprint=se)
    if op == "erode":
        return ndimage.grey_erosion(src, footprint=se)
    if op == "open":
        return ndimage.grey_dilation(ndimage.grey_erosion(src, footprint=se), footprint=se)
    if op == "close":
        return ndimage.grey_erosion(ndimage.grey_dilation(src, footprint=se), footprint=se)
    raise ValueError(op)


def connected_components(mask):
    labels, count = ndimage.label(mask.astype(bool), structure=np.ones((3, 3)))
    return labels, int(count)


def shape_segmentation(mask, min_area=80):
    labels, count = connected_components(mask)
    stats = []
    keep = np.zeros(mask.shape, dtype=bool)
    for lab in range(1, count + 1):
        comp = labels == lab
        area = int(comp.sum())
        if area < min_area:
            continue
        cross = np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]], dtype=bool)
        eroded = ndimage.binary_erosion(comp, structure=cross)
        perim = float(np.sum(comp & ~eroded))
        # A 4-connected perimeter under-counts diagonal steps, so a
        # rasterized circle can score slightly above 1.
        circ = (4.0 * np.pi * area / (perim ** 2)) if perim > 0 else 0.0
        ys, xs = np.where(comp)
        bh, bw = ys.max() - ys.min() + 1, xs.max() - xs.min() + 1
        extent = area / float(bh * bw)
        aspect = bw / float(bh)
        if circ >= 1.0:
            kind = "circle"
        elif extent >= 0.72 and 0.45 <= aspect <= 2.2:
            kind = "rectangle"
        else:
            kind = "other"
        stats.append(
            {
                "label": lab,
                "area": area,
                "circularity": circ,
                "aspect": aspect,
                "extent": extent,
                "kind": kind,
                "bbox": (int(xs.min()), int(ys.min()), int(bw), int(bh)),
            }
        )
        if kind == "circle":
            keep |= comp
    return keep, stats


def _cubic(t):
    a = -0.5
    at = np.abs(t)
    w = np.zeros_like(at, dtype=np.float64)
    m1 = at <= 1
    m2 = (at > 1) & (at < 2)
    w[m1] = (a + 2) * at[m1] ** 3 - (a + 3) * at[m1] ** 2 + 1
    w[m2] = a * at[m2] ** 3 - 5 * a * at[m2] ** 2 + 8 * a * at[m2] - 4 * a
    return w


def resample_image(img, map_x, map_y, method="bilinear", border="constant", cval=0.0):
    src = img.astype(np.float64)
    squeeze = False
    if src.ndim == 2:
        src = src[:, :, None]
        squeeze = True
    h, w, channels = src.shape
    oh, ow = map_x.shape
    if method == "nearest":
        xi = np.rint(map_x).astype(np.int32)
        yi = np.rint(map_y).astype(np.int32)
        if border == "replicate":
            out = src[np.clip(yi, 0, h - 1), np.clip(xi, 0, w - 1)]
        else:
            out = np.full((oh, ow, channels), cval, dtype=np.float64)
            valid = (xi >= 0) & (xi < w) & (yi >= 0) & (yi < h)
            out[valid] = src[yi[valid], xi[valid]]
    elif method == "bilinear":
        x0 = np.floor(map_x).astype(np.int32)
        y0 = np.floor(map_y).astype(np.int32)
        wx = (map_x - x0)[:, :, None]
        wy = (map_y - y0)[:, :, None]

        def sample(yy, xx):
            if border == "replicate":
                return src[np.clip(yy, 0, h - 1), np.clip(xx, 0, w - 1)]
            got = np.full((oh, ow, channels), cval, dtype=np.float64)
            valid = (yy >= 0) & (yy < h) & (xx >= 0) & (xx < w)
            got[valid] = src[yy[valid], xx[valid]]
            return got

        ia = sample(y0, x0)
        ib = sample(y0, x0 + 1)
        ic = sample(y0 + 1, x0)
        id_ = sample(y0 + 1, x0 + 1)
        out = ia * (1 - wx) * (1 - wy) + ib * wx * (1 - wy) + ic * (1 - wx) * wy + id_ * wx * wy
    elif method == "bicubic":
        x_int = np.floor(map_x).astype(np.int32)
        y_int = np.floor(map_y).astype(np.int32)
        dx = map_x - x_int
        dy = map_y - y_int
        out = np.zeros((oh, ow, channels), dtype=np.float64)
        for j in range(-1, 3):
            wy = _cubic(dy - j)[:, :, None]
            yy = y_int + j
            for i in range(-1, 3):
                wx = _cubic(dx - i)[:, :, None]
                xx = x_int + i
                if border == "replicate":
                    samp = src[np.clip(yy, 0, h - 1), np.clip(xx, 0, w - 1)]
                else:
                    samp = np.full((oh, ow, channels), cval, dtype=np.float64)
                    valid = (yy >= 0) & (yy < h) & (xx >= 0) & (xx < w)
                    samp[valid] = src[yy[valid], xx[valid]]
                out += samp * wx * wy
        out = np.clip(out, 0.0, 1.0)
    else:
        raise ValueError(method)
    if squeeze:
        return out[:, :, 0]
    return out


def resize_image(img, new_h, new_w, method="bilinear"):
    src = to_float(img)
    src_h, src_w = src.shape[:2]
    new_h = max(1, int(new_h))
    new_w = max(1, int(new_w))
    ys = (np.arange(new_h) + 0.5) * (src_h / new_h) - 0.5
    xs = (np.arange(new_w) + 0.5) * (src_w / new_w) - 0.5
    map_y, map_x = np.meshgrid(ys, xs, indexing="ij")
    return resample_image(src, map_x, map_y, method, border="replicate")


def _mesh(h, w):
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float64)
    return xx, yy


def translate_image(img, tx, ty, method="bilinear"):
    src = to_float(img)
    h, w = src.shape[:2]
    xx, yy = _mesh(h, w)
    return resample_image(src, xx - tx, yy - ty, method, border="constant", cval=0.0)


def scale_image(img, scale, method="bilinear", same_canvas=True):
    src = to_float(img)
    h, w = src.shape[:2]
    if not same_canvas:
        return resize_image(src, max(1, int(round(h * scale))), max(1, int(round(w * scale))), method)
    cx, cy = (w - 1) / 2.0, (h - 1) / 2.0
    xx, yy = _mesh(h, w)
    return resample_image(src, (xx - cx) / scale + cx, (yy - cy) / scale + cy, method, border="constant")


def rotation_terms(angle_deg):
    """Positive angle is counterclockwise on screen (y points down)."""
    a = np.deg2rad(angle_deg)
    return np.cos(a), np.sin(a)


def _forward_offset(dx, dy, c, s):
    # Screen CCW: east moves toward north (negative y).
    return c * dx + s * dy, -s * dx + c * dy


def _inverse_offset(dx, dy, c, s):
    return c * dx - s * dy, s * dx + c * dy


def rotate_image(img, angle_deg, method="bilinear", mapping="reverse", expand=False):
    src = to_float(img)
    h, w = src.shape[:2]
    cx, cy = (w - 1) / 2.0, (h - 1) / 2.0
    c, s = rotation_terms(angle_deg)
    if expand:
        corners = np.array([[0, 0], [w - 1, 0], [w - 1, h - 1], [0, h - 1]], dtype=np.float64)
        rel = corners - np.array([cx, cy])
        rot = np.stack(_forward_offset(rel[:, 0], rel[:, 1], c, s), axis=1)
        min_xy = rot.min(axis=0)
        max_xy = rot.max(axis=0)
        out_w = int(np.ceil(max_xy[0] - min_xy[0] + 1))
        out_h = int(np.ceil(max_xy[1] - min_xy[1] + 1))
        xx, yy = _mesh(out_h, out_w)
        dest_cx = -min_xy[0]
        dest_cy = -min_xy[1]
        dx, dy = xx - dest_cx, yy - dest_cy
        src_dx, src_dy = _inverse_offset(dx, dy, c, s)
        return resample_image(src, cx + src_dx, cy + src_dy, method, border="constant", cval=0.0)
    xx, yy = _mesh(h, w)
    dx, dy = xx - cx, yy - cy
    if mapping == "forward":
        return rotate_image_forward(src, angle_deg)
    src_dx, src_dy = _inverse_offset(dx, dy, c, s)
    return resample_image(src, cx + src_dx, cy + src_dy, method, border="constant", cval=0.0)


def rotate_image_forward(img, angle_deg):
    src = to_float(img)
    if src.ndim == 3:
        return np.dstack([rotate_image_forward(src[:, :, c], angle_deg) for c in range(src.shape[2])])
    h, w = src.shape
    cx, cy = (w - 1) / 2.0, (h - 1) / 2.0
    c, s = rotation_terms(angle_deg)
    xx, yy = _mesh(h, w)
    fwd_x, fwd_y = _forward_offset(xx - cx, yy - cy, c, s)
    fwd_x = np.rint(cx + fwd_x).astype(np.int32)
    fwd_y = np.rint(cy + fwd_y).astype(np.int32)
    out = np.zeros_like(src)
    valid = (fwd_x >= 0) & (fwd_x < w) & (fwd_y >= 0) & (fwd_y < h)
    out[fwd_y[valid], fwd_x[valid]] = src[valid]
    return out


def affine_warp(img, transform, method="bilinear", mapping="reverse"):
    src = to_float(img)
    transform = np.asarray(transform, dtype=np.float64)
    if transform.shape == (2, 3):
        full = np.eye(3)
        full[:2, :] = transform
        transform = full
    if mapping == "forward":
        if src.ndim == 3:
            return np.dstack([affine_warp(src[:, :, c], transform, method, "forward") for c in range(3)])
        h, w = src.shape
        xx, yy = _mesh(h, w)
        fwd_x = np.rint(transform[0, 0] * xx + transform[0, 1] * yy + transform[0, 2]).astype(np.int32)
        fwd_y = np.rint(transform[1, 0] * xx + transform[1, 1] * yy + transform[1, 2]).astype(np.int32)
        out = np.zeros_like(src)
        valid = (fwd_x >= 0) & (fwd_x < w) & (fwd_y >= 0) & (fwd_y < h)
        out[fwd_y[valid], fwd_x[valid]] = src[valid]
        return out
    inverse = np.linalg.inv(transform)
    h, w = src.shape[:2]
    xx, yy = _mesh(h, w)
    src_x = inverse[0, 0] * xx + inverse[0, 1] * yy + inverse[0, 2]
    src_y = inverse[1, 0] * xx + inverse[1, 1] * yy + inverse[1, 2]
    return resample_image(src, src_x, src_y, method, border="constant", cval=0.0)


def shear_matrix(width, height, shear=0.35):
    cy = (height - 1) / 2.0
    return np.array([[1.0, shear, -shear * cy], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]])


def _radial_scale(xn, yn, k1, k2):
    rd = np.sqrt(xn ** 2 + yn ** 2) + 1e-12
    ru = rd.copy()
    for _ in range(6):
        ru = rd / (1.0 + k1 * ru ** 2 + k2 * ru ** 4)
    return ru / rd


def radial_distortion(img, k1=-0.35, k2=0.05, mode="distort", method="bilinear"):
    src = to_float(img)
    h, w = src.shape[:2]
    cx, cy = (w - 1) / 2.0, (h - 1) / 2.0
    scale = max(cx, cy, 1.0)
    xx, yy = _mesh(h, w)
    xn = (xx - cx) / scale
    yn = (yy - cy) / scale
    if mode == "distort":
        factor = _radial_scale(xn, yn, k1, k2)
    elif mode == "correct":
        r2 = xn ** 2 + yn ** 2
        factor = 1.0 + k1 * r2 + k2 * (r2 ** 2)
    else:
        raise ValueError(mode)
    src_x = cx + xn * factor * scale
    src_y = cy + yn * factor * scale
    return resample_image(src, src_x, src_y, method, border="constant", cval=0.0)


def mutual_information(a, b, bins=32):
    a = as_gray(a)
    b = as_gray(b)
    a = np.clip(np.floor(a * (bins - 1)), 0, bins - 1).astype(np.int32)
    b = np.clip(np.floor(b * (bins - 1)), 0, bins - 1).astype(np.int32)
    joint = np.zeros((bins, bins), dtype=np.float64)
    np.add.at(joint, (a.ravel(), b.ravel()), 1.0)
    joint /= joint.sum() + 1e-12
    p1 = joint.sum(axis=1)
    p2 = joint.sum(axis=0)

    def entropy(p):
        p = p[p > 0]
        return float(-(p * np.log2(p)).sum())

    return entropy(p1) + entropy(p2) - entropy(joint)


def harris_corners(img, max_points=250, sigma=1.2):
    gray = as_gray(img)
    gx, gy, _ = _gradient(gray)
    kernel = gauss_kernel(sigma)
    sxx = ndimage.convolve(gx * gx, kernel, mode="nearest")
    syy = ndimage.convolve(gy * gy, kernel, mode="nearest")
    sxy = ndimage.convolve(gx * gy, kernel, mode="nearest")
    response = (sxx * syy - sxy ** 2) - 0.04 * (sxx + syy) ** 2
    peaks = response == ndimage.maximum_filter(response, size=5)
    thresh = 0.01 * response.max()
    ys, xs = np.where(peaks & (response > thresh))
    if ys.size == 0:
        return np.zeros((0, 2))
    score = response[ys, xs]
    order = np.argsort(score)[::-1][:max_points]
    # Drop points too close to the border for a 15x15 patch.
    pts = np.stack([xs[order], ys[order]], axis=1)
    h, w = gray.shape
    keep = (pts[:, 0] > 8) & (pts[:, 0] < w - 9) & (pts[:, 1] > 8) & (pts[:, 1] < h - 9)
    return pts[keep]


def _patches(gray, pts, rad=7):
    desc = []
    kept = []
    for x, y in pts:
        p = gray[y - rad : y + rad + 1, x - rad : x + rad + 1].astype(np.float64)
        p = p - p.mean()
        norm = np.sqrt(np.sum(p * p)) + 1e-6
        desc.append(p.ravel() / norm)
        kept.append((x, y))
    if not desc:
        return np.zeros((0, 2)), np.zeros((0, (2 * rad + 1) ** 2))
    return np.array(kept), np.stack(desc)


def register_images(fixed, moving, method="bilinear"):
    fixed_g = as_gray(fixed)
    moving_g = as_gray(moving)
    pf = harris_corners(fixed_g, 200)
    pm = harris_corners(moving_g, 200)
    pf, df = _patches(fixed_g, pf)
    pm, dm = _patches(moving_g, pm)
    matches = []
    if len(pf) and len(pm):
        # Mutual nearest neighbors under SSD.
        d2 = ((dm[:, None, :] - df[None, :, :]) ** 2).sum(axis=2)
        nn_f = np.argmin(d2, axis=1)
        nn_m = np.argmin(d2, axis=0)
        for i, j in enumerate(nn_f):
            if nn_m[j] == i and d2[i, j] < 0.8:
                matches.append((pm[i], pf[j]))
    transform = np.eye(3)
    inliers = 0
    if len(matches) >= 2:
        src = np.array([m[0] for m in matches], dtype=np.float64)
        dst = np.array([m[1] for m in matches], dtype=np.float64)
        best_inl = None
        best_count = -1
        rng = np.random.default_rng(3)
        n = len(matches)
        for _ in range(250):
            i1, i2 = rng.choice(n, 2, replace=False)
            v1 = src[i2] - src[i1]
            v2 = dst[i2] - dst[i1]
            if np.hypot(*v1) < 8 or np.hypot(*v2) < 8:
                continue
            ang = np.arctan2(v2[1], v2[0]) - np.arctan2(v1[1], v1[0])
            c, s = np.cos(ang), np.sin(ang)
            rot = np.array([[c, -s], [s, c]])
            trans = dst[i1] - rot @ src[i1]
            pred = (rot @ src.T).T + trans
            err = np.linalg.norm(pred - dst, axis=1)
            inl = err < 3.0
            count = int(inl.sum())
            if count > best_count:
                best_count = count
                best_inl = (ang, rot, trans, inl)
        if best_inl is not None and best_count >= 3:
            ang, rot, trans, inl = best_inl
            rot = rot
            trans = dst[inl].mean(axis=0) - (rot @ src[inl].T).mean(axis=1)
            transform = np.array(
                [[rot[0, 0], rot[0, 1], trans[0]], [rot[1, 0], rot[1, 1], trans[1]], [0, 0, 1]],
                dtype=np.float64,
            )
            inliers = best_count
    aligned = affine_warp(to_float(moving), transform, method=method, mapping="reverse")
    info = {
        "transform": transform,
        "inliers": inliers,
        "matches": len(matches),
        "angle_deg": float(np.rad2deg(np.arctan2(transform[1, 0], transform[0, 0]))),
        "translation": (float(transform[0, 2]), float(transform[1, 2])),
        "mi_before": mutual_information(fixed, moving),
        "mi_after": mutual_information(fixed, aligned),
    }
    return aligned, info


def skin_mask(img):
    src = to_float(img)
    if src.ndim == 2:
        return np.zeros(src.shape, dtype=bool)
    # Lift a dark frame only for the test so the same chrominance rule
    # still fires after underexposure. The displayed image is not changed.
    gray = as_gray(src)
    p90 = float(np.percentile(gray, 90))
    if 0.02 < p90 < 0.45:
        src = np.clip(src * (0.55 / p90), 0.0, 1.0)
    ycbcr = rgb_to_ycbcr(src)
    y = ycbcr[:, :, 0] * 255.0
    cb = ycbcr[:, :, 1] * 255.0
    cr = ycbcr[:, :, 2] * 255.0
    # Chrominance gate keeps saturated red objects (the balloon) out.
    mask = (y > 50) & (cb >= 85) & (cb <= 130) & (cr >= 136) & (cr <= 178)
    mask = morph_operation(mask.astype(np.uint8), "open", 2, "disk")
    mask = morph_operation(mask.astype(np.uint8), "close", 7, "disk")
    labels, count = connected_components(mask)
    if count:
        min_area = 0.005 * mask.size
        keep = np.zeros(mask.shape, dtype=bool)
        for lab in range(1, count + 1):
            comp = labels == lab
            if comp.sum() >= min_area:
                keep |= comp
        mask = keep
    return mask.astype(bool)


def detect_face_regions(img):
    src = to_float(img)
    gray = as_gray(src)
    mask = skin_mask(src)
    labels, count = connected_components(mask)
    faces = []
    if count == 0:
        return {"faces": faces, "skin": mask}
    areas = ndimage.sum(np.ones_like(labels), labels, index=np.arange(1, count + 1))
    order = np.argsort(np.atleast_1d(areas))[::-1]
    h, w = gray.shape
    for idx in order[:3]:
        lab = int(idx) + 1
        comp = labels == lab
        area = int(np.atleast_1d(areas)[idx])
        if area < 0.01 * h * w:
            continue
        present = comp.any(axis=1)
        cols_idx = np.arange(comp.shape[1])
        max_col = np.where(comp, cols_idx, -1).max(axis=1)
        min_col = np.where(comp, cols_idx, comp.shape[1]).min(axis=1)
        span = np.where(present, max_col - min_col + 1, 0)
        if span.max() < 8:
            continue
        # Span, not pixel count: eye holes must not split the face in two.
        # The neck is the narrow column below the cheeks.
        rows = np.where(span >= 0.58 * span.max())[0]
        if rows.size == 0:
            continue
        splits = np.where(np.diff(rows) > 1)[0]
        bands = np.split(rows, splits + 1)
        band = max(bands, key=len)
        y0, y1 = int(band[0]), int(band[-1])
        cols = np.where(comp[y0 : y1 + 1].any(axis=0))[0]
        if cols.size == 0:
            continue
        x0, x1 = int(cols[0]), int(cols[-1])
        bw, bh = x1 - x0 + 1, y1 - y0 + 1
        if bh < 20 or bw < 20:
            continue
        aspect = bh / float(bw)
        if aspect < 0.7 or aspect > 2.4:
            continue
        sub = gray[y0 : y1 + 1, x0 : x1 + 1]
        eyes = _find_eyes(sub)
        if eyes is None:
            left = np.array([x0 + 0.32 * bw, y0 + 0.40 * bh])
            right = np.array([x0 + 0.68 * bw, y0 + 0.40 * bh])
            eye_source = "geometric"
        else:
            left = np.array([x0 + eyes[0][0], y0 + eyes[0][1]])
            right = np.array([x0 + eyes[1][0], y0 + eyes[1][1]])
            eye_source = "detected"
        angle = np.arctan2(right[1] - left[1], right[0] - left[0])
        direction = np.array([np.cos(angle + np.pi / 2), np.sin(angle + np.pi / 2)])
        eye_mid = (left + right) / 2.0
        eye_dist = np.linalg.norm(right - left) + 1e-6
        nose = eye_mid + direction * (0.38 * eye_dist)
        mouth = eye_mid + direction * (0.85 * eye_dist)
        faces.append(
            {
                "bbox": (x0, y0, bw, bh),
                "left_eye": left,
                "right_eye": right,
                "nose": nose,
                "mouth": mouth,
                "angle": float(angle),
                "eye_dist": float(eye_dist),
                "eye_source": eye_source,
            }
        )
    return {"faces": faces, "skin": mask}


def _find_eyes(face_gray):
    h, w = face_gray.shape
    y_a, y_b = int(0.28 * h), int(0.58 * h)
    band = face_gray[y_a:y_b]
    if band.size == 0:
        return None
    level = np.percentile(band, 22)
    dark = band <= level
    dark = ndimage.binary_opening(dark, structure=_disk(1))
    labels, count = connected_components(dark)
    if count == 0:
        return None
    cands = []
    for lab in range(1, count + 1):
        comp = labels == lab
        area = int(comp.sum())
        if area < 12 or area > 0.08 * h * w:
            continue
        ys, xs = np.where(comp)
        cands.append((area, xs.mean(), ys.mean() + y_a))
    if len(cands) < 2:
        return None
    cands.sort(reverse=True)
    chosen = None
    for i in range(min(6, len(cands))):
        for j in range(i + 1, min(6, len(cands))):
            _, x1, y1 = cands[i]
            _, x2, y2 = cands[j]
            dx = abs(x1 - x2)
            dy = abs(y1 - y2)
            if 0.18 * w <= dx <= 0.70 * w and dy <= 0.18 * h:
                chosen = ((x1, y1), (x2, y2)) if x1 < x2 else ((x2, y2), (x1, y1))
                break
        if chosen:
            break
    return chosen


def alpha_blend(background, sprite, left, top):
    bg = to_float(background)
    if bg.ndim == 2:
        bg = np.dstack([bg, bg, bg])
    sp = sprite.astype(np.float64)
    if sp.max(initial=0) > 1.5:
        sp = sp / 255.0
    if sp.shape[2] == 3:
        sp = np.dstack([sp, np.ones(sp.shape[:2])])
    h, w = bg.shape[:2]
    sh, sw = sp.shape[:2]
    x0, y0 = int(round(left)), int(round(top))
    x1, y1 = x0 + sw, y0 + sh
    bx0, by0 = max(0, x0), max(0, y0)
    bx1, by1 = min(w, x1), min(h, y1)
    out = bg.copy()
    if bx0 >= bx1 or by0 >= by1:
        return out
    fx0, fy0 = bx0 - x0, by0 - y0
    fx1, fy1 = fx0 + (bx1 - bx0), fy0 + (by1 - by0)
    crop = sp[fy0:fy1, fx0:fx1]
    alpha = crop[:, :, 3:4]
    roi = out[by0:by1, bx0:bx1]
    out[by0:by1, bx0:bx1] = crop[:, :, :3] * alpha + roi * (1.0 - alpha)
    return np.clip(out, 0, 1)


def rotate_rgba(sprite, angle_deg, method="bilinear"):
    """Rotate around the sprite center and return (image, anchor_xy_in_new)."""
    src = sprite.astype(np.float64)
    if src.max(initial=0) > 1.5:
        src = src / 255.0
    h, w = src.shape[:2]
    cx, cy = (w - 1) / 2.0, (h - 1) / 2.0
    c, s = rotation_terms(angle_deg)
    corners = np.array([[0, 0], [w - 1, 0], [w - 1, h - 1], [0, h - 1]], dtype=np.float64)
    rel = corners - np.array([cx, cy])
    rot = np.stack(_forward_offset(rel[:, 0], rel[:, 1], c, s), axis=1)
    min_xy = rot.min(0)
    max_xy = rot.max(0)
    out_w = int(np.ceil(max_xy[0] - min_xy[0] + 1))
    out_h = int(np.ceil(max_xy[1] - min_xy[1] + 1))
    dest_cx = -min_xy[0]
    dest_cy = -min_xy[1]
    xx, yy = _mesh(out_h, out_w)
    dx, dy = xx - dest_cx, yy - dest_cy
    src_dx, src_dy = _inverse_offset(dx, dy, c, s)
    src_x = cx + src_dx
    src_y = cy + src_dy
    planes = [
        resample_image(src[:, :, ch], src_x, src_y, method, border="constant", cval=0.0)
        for ch in range(src.shape[2])
    ]
    return np.dstack(planes), np.array([dest_cx, dest_cy])


def place_sprite(background, sprite, dest_xy, width_px, angle_deg, anchor_norm, method="bilinear"):
    sp = sprite.astype(np.float64)
    if sp.max(initial=0) > 1.5:
        sp = sp / 255.0
    sh, sw = sp.shape[:2]
    new_w = max(1, int(round(width_px)))
    new_h = max(1, int(round(sh * (new_w / float(sw)))))
    scaled = np.dstack([resize_image(sp[:, :, c], new_h, new_w, method) for c in range(sp.shape[2])])
    rotated, center = rotate_rgba(scaled, angle_deg, method)
    anchor = np.array(
        [anchor_norm[0] * (scaled.shape[1] - 1), anchor_norm[1] * (scaled.shape[0] - 1)],
        dtype=np.float64,
    )
    # Anchor moves with the same forward rotation used by rotate_rgba.
    c, s = rotation_terms(angle_deg)
    rel = anchor - np.array([(scaled.shape[1] - 1) / 2.0, (scaled.shape[0] - 1) / 2.0])
    moved_x, moved_y = _forward_offset(rel[0], rel[1], c, s)
    moved = np.array([moved_x, moved_y]) + center
    left = dest_xy[0] - moved[0]
    top = dest_xy[1] - moved[1]
    return alpha_blend(background, rotated, left, top)


FILTERS = {
    "glasses": {"file": "glasses.png", "anchor": "eyes", "width": 2.55, "anchor_norm": (0.50, 0.50)},
    "mustache": {"file": "mustache.png", "anchor": "nose", "width": 1.55, "anchor_norm": (0.50, 0.18)},
    "hat": {"file": "hat.png", "anchor": "forehead", "width": 2.05, "anchor_norm": (0.50, 0.90)},
    "party": {"file": "party.png", "anchor": "forehead", "width": 1.35, "anchor_norm": (0.50, 0.92)},
    "dog": {"file": "dog_ears.png", "anchor": "ears", "width": 2.35, "anchor_norm": (0.50, 0.78)},
    "nose": {"file": "dog_nose.png", "anchor": "nose", "width": 0.85, "anchor_norm": (0.50, 0.55)},
}


def apply_ar_filter(img, name="glasses", method="bilinear", enhance=False, assets=None, scale=1.0):
    src = to_float(img)
    # Skin detection already lifts a dark frame. Equalization is applied
    # to the pixels we draw on, after the landmarks are known, so the
    # chrominance gate is not distorted by the histogram map.
    det = detect_face_regions(src)
    out = histogram_equalize(src) if enhance else src.copy()
    if name == "beauty":
        return beauty_filter(src, det), det
    if name == "bgblur":
        return background_blur(src, det), det
    if name == "colorpop":
        return color_pop(src, "red"), det
    if not det["faces"]:
        return out, det
    sequence = []
    if name == "combo":
        sequence = ["hat", "glasses", "mustache"]
    elif name == "dog":
        sequence = ["dog", "nose"]
    else:
        sequence = [name]
    face = det["faces"][0]
    # atan2 in y-down is clockwise-positive. The rotator is counterclockwise-positive.
    angle = -np.rad2deg(face["angle"])
    eye_mid = (face["left_eye"] + face["right_eye"]) / 2.0
    direction = np.array([np.cos(face["angle"] + np.pi / 2), np.sin(face["angle"] + np.pi / 2)])
    for key in sequence:
        spec = FILTERS[key]
        if spec["anchor"] == "eyes":
            dest = eye_mid + direction * (0.02 * face["eye_dist"])
            width = spec["width"] * face["eye_dist"] * scale
        elif spec["anchor"] == "nose":
            dest = face["nose"]
            width = spec["width"] * face["eye_dist"] * scale
        elif spec["anchor"] == "forehead":
            dest = eye_mid - direction * (1.05 * face["eye_dist"])
            width = spec["width"] * face["eye_dist"] * scale
        else:
            dest = eye_mid - direction * (1.15 * face["eye_dist"])
            width = spec["width"] * face["eye_dist"] * scale
        sprite = assets[spec["file"]]
        out = place_sprite(out, sprite, dest, width, angle, spec["anchor_norm"], method)
    return out, det


def beauty_filter(img, det=None):
    src = to_float(img)
    if det is None:
        det = detect_face_regions(src)
    smooth = spatial_median_filter(src, 5)
    skin = det["skin"]
    mag = sobel_edge(src, 0.12)[0]
    edges = mag > 0.18
    alpha = skin & ~edges
    alpha_f = ndimage.gaussian_filter(alpha.astype(np.float64), 1.2)[:, :, None]
    mixed = src * (1 - alpha_f) + smooth * alpha_f
    # A small contrast lift on the face, still inside Student 1's module.
    lifted = gray_level_transform(mixed, "both", amount=0.02, contrast=1.08)
    return np.clip(src * (1 - alpha_f) + lifted * alpha_f, 0, 1)


def background_blur(img, det=None):
    src = to_float(img)
    if det is None:
        det = detect_face_regions(src)
    h, w = src.shape[:2]
    fg = det["skin"].copy()
    for face in det["faces"]:
        x, y, bw, bh = face["bbox"]
        x0 = max(0, int(x - 0.25 * bw))
        x1 = min(w, int(x + 1.25 * bw))
        y0 = max(0, int(y - 0.15 * bh))
        y1 = min(h, int(y + 2.4 * bh))
        fg[y0:y1, x0:x1] = True
    fg = morph_operation(fg.astype(np.uint8), "close", 12, "disk").astype(bool)
    blur = frequency_filter(src, "lowpass", d0=18, response="gaussian")
    alpha = ndimage.gaussian_filter(fg.astype(np.float64), 3.0)[:, :, None]
    return np.clip(src * alpha + blur * (1 - alpha), 0, 1)


def color_pop(img, target="red"):
    src = to_float(img)
    mask = color_segmentation(src, target)
    alpha = ndimage.gaussian_filter(mask.astype(np.float64), 0.6)[:, :, None]
    hsv = rgb_to_hsv(src)
    hsv[:, :, 1] = 0
    grayish = hsv_to_rgb(hsv)
    return np.clip(src * alpha + grayish * (1 - alpha), 0, 1)


def psnr(a, b):
    a = to_float(a)
    b = to_float(b)
    mse = np.mean((a - b) ** 2)
    if mse < 1e-12:
        return 99.0
    return float(10.0 * np.log10(1.0 / mse))

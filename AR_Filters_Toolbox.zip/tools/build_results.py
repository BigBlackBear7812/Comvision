"""Create sample images, filter artwork, and the figures used in the report."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

import ip_core as ip  # noqa: E402

SAMPLES = ROOT / "samples"
ASSETS = ROOT / "assets"
RESULTS = ROOT / "results"


def save_uint(path, img):
    path = Path(path)
    arr = ip.to_uint8(img)
    Image.fromarray(arr).save(path)


def save_rgba(path, img):
    arr = np.clip(np.rint(img * 255), 0, 255).astype(np.uint8)
    Image.fromarray(arr, mode="RGBA").save(path)


def show(ax, img, title):
    img = np.asarray(img)
    if img.dtype == np.bool_ or (img.ndim == 2 and img.dtype != np.uint8):
        ax.imshow(img.astype(float), cmap="gray", vmin=0, vmax=1)
    elif img.ndim == 2:
        ax.imshow(img, cmap="gray", vmin=0, vmax=255)
    else:
        ax.imshow(np.clip(img, 0, 1))
    ax.set_title(title, fontsize=11)
    ax.axis("off")


def figure(images, path, cols=None, suptitle=None):
    n = len(images)
    cols = cols or n
    rows = int(np.ceil(n / cols))
    fig, axes = plt.subplots(rows, cols, figsize=(4.1 * cols, 3.6 * rows))
    axes = np.atleast_1d(axes).ravel()
    for ax, (img, title) in zip(axes, images):
        show(ax, img, title)
    for ax in axes[n:]:
        ax.axis("off")
    if suptitle:
        fig.suptitle(suptitle, fontsize=14)
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)


def draw_portrait():
    img = Image.new("RGB", (640, 800), (214, 222, 230))
    d = ImageDraw.Draw(img)
    d.ellipse([36, 500, 170, 690], fill=(64, 148, 78))
    d.rectangle([92, 650, 116, 760], fill=(92, 62, 40))
    d.ellipse([488, 90, 610, 230], fill=(204, 42, 52))
    d.line([548, 228, 530, 330], fill=(70, 70, 70), width=4)
    d.pieslice([120, 545, 530, 980], 200, 340, fill=(36, 92, 180))
    d.rectangle([286, 505, 362, 650], fill=(232, 186, 150))
    d.ellipse([146, 300, 208, 410], fill=(226, 176, 142))
    d.ellipse([432, 300, 494, 410], fill=(226, 176, 142))
    d.ellipse([155, 115, 485, 390], fill=(46, 30, 22))
    d.ellipse([150, 190, 214, 540], fill=(46, 30, 22))
    d.ellipse([426, 190, 492, 540], fill=(46, 30, 22))
    d.ellipse([176, 160, 464, 545], fill=(236, 196, 162))
    d.chord([165, 118, 475, 300], 200, 340, fill=(46, 30, 22))
    d.ellipse([228, 318, 308, 372], fill=(250, 250, 250))
    d.ellipse([348, 318, 428, 372], fill=(250, 250, 250))
    d.ellipse([250, 326, 294, 368], fill=(42, 30, 22))
    d.ellipse([370, 326, 414, 368], fill=(42, 30, 22))
    d.ellipse([264, 338, 284, 356], fill=(12, 12, 12))
    d.ellipse([384, 338, 404, 356], fill=(12, 12, 12))
    d.arc([220, 292, 314, 332], 200, 350, fill=(40, 26, 18), width=5)
    d.arc([340, 292, 434, 332], 190, 340, fill=(40, 26, 18), width=5)
    d.arc([300, 355, 352, 455], 10, 170, fill=(176, 120, 104), width=4)
    d.arc([268, 438, 386, 510], 10, 170, fill=(168, 64, 78), width=6)
    d.ellipse([205, 392, 252, 426], fill=(228, 150, 142))
    d.ellipse([400, 392, 447, 426], fill=(228, 150, 142))
    return np.asarray(img).astype(np.float64) / 255.0


def draw_house():
    img = Image.new("RGB", (480, 360), (245, 245, 245))
    d = ImageDraw.Draw(img)
    d.rectangle([90, 160, 300, 300], outline=(20, 20, 20), width=4)
    d.polygon([(70, 160), (195, 60), (320, 160)], outline=(20, 20, 20))
    d.line([(70, 160), (195, 60), (320, 160)], fill=(20, 20, 20), width=4)
    d.rectangle([170, 210, 220, 300], outline=(20, 20, 20), width=3)
    d.rectangle([110, 190, 150, 230], outline=(20, 20, 20), width=3)
    d.ellipse([340, 70, 450, 180], outline=(20, 20, 20), width=6)
    d.line([20, 330, 460, 330], fill=(180, 180, 180), width=2)
    arr = np.asarray(img).astype(np.float64) / 255.0
    rng = np.random.default_rng(1)
    noise = rng.normal(0, 0.015, arr.shape[:2])
    arr = np.clip(arr + noise[:, :, None], 0, 1)
    return arr


def draw_shapes():
    img = np.full((320, 420), 46, dtype=np.float64)
    canvas = Image.fromarray(img.astype(np.uint8))
    d = ImageDraw.Draw(canvas)
    d.ellipse([40, 40, 160, 160], fill=230)
    d.ellipse([230, 50, 330, 150], fill=230)
    d.rectangle([60, 200, 180, 290], fill=225)
    d.polygon([(280, 190), (390, 210), (350, 300), (250, 280)], fill=210)
    return np.asarray(canvas).astype(np.float64) / 255.0


def draw_grid():
    img = np.ones((360, 360), dtype=np.float64)
    img[::24, :] = 0.15
    img[:, ::24] = 0.15
    img[168:192, 168:192] = 0.45
    return img


def salt_pepper(img, amount=0.05):
    rng = np.random.default_rng(2)
    out = ip.to_float(img).copy()
    picks = rng.random(out.shape[:2])
    salt = picks < amount / 2
    pepper = (picks >= amount / 2) & (picks < amount)
    if out.ndim == 2:
        out[salt] = 1
        out[pepper] = 0
    else:
        out[salt] = 1
        out[pepper] = 0
    return out


def make_assets():
    glasses = Image.new("RGBA", (900, 280), (0, 0, 0, 0))
    g = ImageDraw.Draw(glasses)
    g.rounded_rectangle([30, 36, 410, 244], radius=90, outline=(18, 18, 22, 255), width=22)
    g.rounded_rectangle([490, 36, 870, 244], radius=90, outline=(18, 18, 22, 255), width=22)
    g.rounded_rectangle([52, 58, 388, 222], radius=70, fill=(20, 28, 48, 105))
    g.rounded_rectangle([512, 58, 848, 222], radius=70, fill=(20, 28, 48, 105))
    g.rectangle([400, 118, 500, 150], fill=(18, 18, 22, 255))
    g.arc([80, 70, 250, 150], 200, 340, fill=(255, 255, 255, 150), width=8)
    g.arc([540, 70, 710, 150], 200, 340, fill=(255, 255, 255, 150), width=8)

    mustache = Image.new("RGBA", (700, 240), (0, 0, 0, 0))
    m = ImageDraw.Draw(mustache)
    m.polygon([(40, 90), (180, 40), (330, 110), (350, 70), (370, 110), (520, 40), (660, 90),
               (560, 170), (430, 150), (350, 190), (270, 150), (140, 170)], fill=(48, 28, 18, 255))
    m.ellipse([250, 95, 450, 175], fill=(32, 18, 12, 255))

    hat = Image.new("RGBA", (560, 460), (0, 0, 0, 0))
    h = ImageDraw.Draw(hat)
    h.rectangle([175, 30, 385, 300], fill=(22, 22, 28, 255))
    h.ellipse([40, 250, 520, 360], fill=(22, 22, 28, 255))
    h.rectangle([175, 230, 385, 275], fill=(176, 32, 44, 255))
    h.rectangle([188, 48, 210, 220], fill=(255, 255, 255, 40))

    party = Image.new("RGBA", (420, 460), (0, 0, 0, 0))
    p = ImageDraw.Draw(party)
    p.polygon([(210, 24), (46, 400), (374, 400)], fill=(232, 176, 28, 255))
    p.polygon([(210, 24), (110, 250), (210, 230), (300, 250)], fill=(214, 64, 70, 255))
    p.ellipse([150, 378, 270, 430], fill=(232, 176, 28, 255))

    ears = Image.new("RGBA", (760, 420), (0, 0, 0, 0))
    e = ImageDraw.Draw(ears)
    e.polygon([(40, 300), (70, 40), (230, 20), (250, 300)], fill=(122, 72, 40, 255))
    e.polygon([(80, 250), (110, 80), (190, 70), (200, 250)], fill=(214, 150, 150, 255))
    e.polygon([(720, 300), (690, 40), (530, 20), (510, 300)], fill=(122, 72, 40, 255))
    e.polygon([(680, 250), (650, 80), (570, 70), (560, 250)], fill=(214, 150, 150, 255))

    nose = Image.new("RGBA", (260, 200), (0, 0, 0, 0))
    n = ImageDraw.Draw(nose)
    n.ellipse([30, 20, 230, 170], fill=(92, 52, 36, 255))
    n.ellipse([70, 80, 120, 140], fill=(30, 16, 12, 255))
    n.ellipse([140, 80, 190, 140], fill=(30, 16, 12, 255))

    for im, name in (
        (glasses, "glasses.png"),
        (mustache, "mustache.png"),
        (hat, "hat.png"),
        (party, "party.png"),
        (ears, "dog_ears.png"),
        (nose, "dog_nose.png"),
    ):
        im.save(ASSETS / name)
    return {
        "glasses.png": np.asarray(glasses).astype(np.float64) / 255.0,
        "mustache.png": np.asarray(mustache).astype(np.float64) / 255.0,
        "hat.png": np.asarray(hat).astype(np.float64) / 255.0,
        "party.png": np.asarray(party).astype(np.float64) / 255.0,
        "dog_ears.png": np.asarray(ears).astype(np.float64) / 255.0,
        "dog_nose.png": np.asarray(nose).astype(np.float64) / 255.0,
    }


def overlay_detection(img, det):
    canvas = (ip.to_float(img) * 255).astype(np.uint8)
    im = Image.fromarray(canvas)
    d = ImageDraw.Draw(im)
    for face in det["faces"]:
        x, y, w, h = face["bbox"]
        d.rectangle([x, y, x + w, y + h], outline=(255, 64, 64), width=3)
        for key, color in (("left_eye", (40, 90, 255)), ("right_eye", (40, 90, 255)),
                           ("nose", (40, 180, 40)), ("mouth", (230, 140, 20))):
            px, py = face[key]
            d.ellipse([px - 5, py - 5, px + 5, py + 5], fill=color)
    return np.asarray(im).astype(np.float64) / 255.0


def check_rotation():
    img = np.zeros((21, 21), dtype=np.float64)
    img[10, 18] = 1.0
    rot = ip.rotate_image(img, 90, method="nearest")
    ys, xs = np.where(rot > 0.5)
    if not (len(xs) == 1 and abs(int(xs[0]) - 10) <= 1 and int(ys[0]) <= 4):
        raise RuntimeError(f"rotation convention failed: x={xs} y={ys}")


def main():
    SAMPLES.mkdir(exist_ok=True)
    ASSETS.mkdir(exist_ok=True)
    RESULTS.mkdir(exist_ok=True)
    check_rotation()
    portrait = draw_portrait()
    house = draw_house()
    shapes = draw_shapes()
    grid = draw_grid()
    dark = np.clip(portrait * 0.32, 0, 1)
    noisy = salt_pepper(portrait, 0.06)
    save_uint(SAMPLES / "portrait.png", portrait)
    save_uint(SAMPLES / "portrait_dark.png", dark)
    save_uint(SAMPLES / "portrait_noise.png", noisy)
    save_uint(SAMPLES / "house.png", house)
    save_uint(SAMPLES / "shapes.png", shapes)
    save_uint(SAMPLES / "grid.png", grid)
    assets = make_assets()

    metrics = {}
    eq = ip.histogram_equalize(dark)
    metrics["dark_std"] = float(ip.as_gray(dark).std())
    metrics["eq_std"] = float(ip.as_gray(eq).std())
    matched = ip.histogram_match(dark, portrait)
    bright = ip.gray_level_transform(portrait, "both", amount=0.12, contrast=1.45)
    gamma = ip.gray_level_transform(portrait, "gamma", gamma=0.6)
    negative = ip.gray_level_transform(ip.as_gray(portrait), "negative")
    mean_f = ip.spatial_mean_filter(noisy, 3)
    median_f = ip.spatial_median_filter(noisy, 3)
    metrics["psnr_noisy"] = ip.psnr(portrait, noisy)
    metrics["psnr_mean"] = ip.psnr(portrait, mean_f)
    metrics["psnr_median"] = ip.psnr(portrait, median_f)
    sharp = ip.laplacian_sharpen(portrait, 0.8)
    unsharp = ip.high_pass_sharpen(portrait, 5, 0.9)
    low = ip.frequency_filter(portrait, "lowpass", 28, response="gaussian")
    high = ip.frequency_filter(portrait, "highpass", 24, response="gaussian")
    band = ip.frequency_filter(portrait, "bandpass", 40, width=28, response="gaussian")
    ideal = ip.frequency_filter(ip.as_gray(portrait), "lowpass", 30, response="ideal")

    figure(
        [(dark, "Dark input"), (eq, "Histogram equalization"), (matched, "Matched to the original")],
        RESULTS / "m1_histogram.png",
    )
    figure(
        [(portrait, "Original"), (bright, "Brightness and contrast"), (gamma, "Gamma 0.6"), (negative, "Negative")],
        RESULTS / "m1_graylevel.png",
    )
    figure(
        [(noisy, "Salt-and-pepper noise"), (mean_f, "Mean 3x3"), (median_f, "Median 3x3")],
        RESULTS / "m1_denoise.png",
    )
    figure(
        [(portrait, "Original"), (sharp, "Laplacian sharpen"), (unsharp, "Unsharp mask")],
        RESULTS / "m1_sharpen.png",
    )
    figure(
        [(portrait, "Original"), (low, "Gaussian low-pass"), (high, "Gaussian high-pass"), (band, "Gaussian band-pass"), (ideal, "Ideal low-pass")],
        RESULTS / "m1_frequency.png",
        cols=3,
    )

    sobel_m, sobel_b = ip.sobel_edge(house, 0.18)
    prewitt_m, prewitt_b = ip.prewitt_edge(house, 0.18)
    _nms, canny_b = ip.canny_edge(house, 1.4, 0.04, 0.14)
    metrics["edge_pixels"] = {
        "sobel": int(sobel_b.sum()),
        "prewitt": int(prewitt_b.sum()),
        "canny": int(canny_b.sum()),
    }
    figure(
        [(house, "House scene"), (sobel_b, "Sobel"), (prewitt_b, "Prewitt"), (canny_b, "Canny")],
        RESULTS / "m2_edges.png",
    )
    level, otsu_mask, _ = ip.otsu_threshold(shapes)
    metrics["otsu_level"] = int(level)
    seed = (470, 320)
    grown = ip.region_growing(portrait, seed, tol=0.20)
    red = ip.color_segmentation(portrait, "red")
    blue = ip.color_segmentation(portrait, "blue")
    skin = ip.color_segmentation(portrait, "skin")
    opened = ip.morph_operation(otsu_mask, "open", 3, "disk")
    closed = ip.morph_operation(otsu_mask, "close", 6, "disk")
    dilated = ip.morph_operation(otsu_mask, "dilate", 4, "disk")
    eroded = ip.morph_operation(otsu_mask, "erode", 4, "disk")
    circles, shape_stats = ip.shape_segmentation(otsu_mask)
    metrics["shapes"] = [
        {"kind": s["kind"], "circularity": round(s["circularity"], 3), "area": s["area"]}
        for s in shape_stats
    ]
    figure(
        [(shapes, "Shapes"), (otsu_mask, f"Otsu mask (t={level})"), (circles, "Circles kept by shape")],
        RESULTS / "m2_otsu_shape.png",
    )
    figure(
        [(portrait, "Original"), (grown, "Region growing from the cheek"), (skin, "Skin segmentation")],
        RESULTS / "m2_region_skin.png",
    )
    figure(
        [(red, "Red in HSV"), (blue, "Blue in HSV"), (dilated, "Dilation"), (eroded, "Erosion"), (opened, "Opening"), (closed, "Closing")],
        RESULTS / "m2_color_morph.png",
        cols=3,
    )

    moved = ip.translate_image(portrait, 40, -30)
    zoomed = ip.scale_image(portrait, 1.6, method="bilinear", same_canvas=True)
    turned = ip.rotate_image(portrait, 18, method="bilinear")
    forward = ip.rotate_image_forward(ip.as_gray(portrait), 18)
    reverse = ip.rotate_image(ip.as_gray(portrait), 18, method="bilinear")
    patch = portrait[300:360, 250:310]
    near = ip.resize_image(patch, 240, 240, "nearest")
    bilin = ip.resize_image(patch, 240, 240, "bilinear")
    bicube = ip.resize_image(patch, 240, 240, "bicubic")
    sheared = ip.affine_warp(portrait, ip.shear_matrix(portrait.shape[1], portrait.shape[0], 0.28))
    # Pad first so the warp can sample past the border, then crop back.
    pad = 120
    k1 = -0.22
    padded = np.pad(grid, pad, mode="reflect")
    barrel_big = ip.radial_distortion(padded, k1=k1, k2=0.0, mode="distort")
    fixed_big = ip.radial_distortion(barrel_big, k1=k1, k2=0.0, mode="correct")
    barrel = barrel_big[pad:-pad, pad:-pad]
    fixed_back = fixed_big[pad:-pad, pad:-pad]
    metrics["distortion_k1"] = k1
    metrics["distortion_psnr"] = round(ip.psnr(grid, fixed_back), 2)
    moving = ip.translate_image(ip.rotate_image(portrait, 8, method="bilinear"), 22, -16)
    save_uint(SAMPLES / "portrait_moving.png", moving)
    aligned, reg = ip.register_images(portrait, moving)
    metrics["registration"] = {
        "matches": reg["matches"],
        "inliers": reg["inliers"],
        "angle_deg": round(reg["angle_deg"], 2),
        "translation": [round(v, 2) for v in reg["translation"]],
        "mi_before": round(reg["mi_before"], 3),
        "mi_after": round(reg["mi_after"], 3),
        "psnr_aligned": round(ip.psnr(portrait[50:-50, 50:-50], aligned[50:-50, 50:-50]), 2),
    }
    figure(
        [(portrait, "Original"), (moved, "Translation (40, -30)"), (zoomed, "Scale 1.6 about center"), (turned, "Rotation +18 deg")],
        RESULTS / "m3_geometry.png",
    )
    figure(
        [(ip.as_gray(portrait), "Source"), (forward, "Forward map (holes)"), (reverse, "Reverse map")],
        RESULTS / "m3_mapping.png",
    )
    figure(
        [(near, "Nearest neighbor"), (bilin, "Bilinear"), (bicube, "Bicubic")],
        RESULTS / "m3_interpolation.png",
        suptitle="4x enlargement of an eye patch",
    )
    figure(
        [(sheared, "Affine shear"), (grid, "Grid"), (barrel, "Barrel distortion"), (fixed_back, "After correction")],
        RESULTS / "m3_affine_lens.png",
    )
    figure(
        [(portrait, "Fixed"), (moving, "Moving (rotated and shifted)"), (aligned, "Registered")],
        RESULTS / "m3_registration.png",
    )

    det = ip.detect_face_regions(portrait)
    metrics["faces"] = len(det["faces"])
    if det["faces"]:
        face = det["faces"][0]
        metrics["eye_source"] = face["eye_source"]
        metrics["eye_dist"] = round(face["eye_dist"], 2)
        metrics["left_eye"] = [round(float(v), 1) for v in face["left_eye"]]
        metrics["right_eye"] = [round(float(v), 1) for v in face["right_eye"]]
        # Drawn iris centers are approximately (272, 347) and (392, 347).
        metrics["eye_error_px"] = round(
            float(
                (
                    np.hypot(face["left_eye"][0] - 272, face["left_eye"][1] - 347)
                    + np.hypot(face["right_eye"][0] - 392, face["right_eye"][1] - 347)
                )
                / 2
            ),
            2,
        )
    detected = overlay_detection(portrait, det)
    save_uint(RESULTS / "ar_landmarks.png", detected)

    outputs = {}
    for name in ("glasses", "mustache", "hat", "party", "dog", "combo", "beauty", "bgblur", "colorpop"):
        outputs[name], _ = ip.apply_ar_filter(portrait, name, method="bilinear", assets=assets)
        save_uint(RESULTS / f"ar_{name}.png", outputs[name])
    tilted = ip.rotate_image(portrait, -12, method="bilinear", expand=True)
    tilt_out, tilt_det = ip.apply_ar_filter(tilted, "glasses", method="bilinear", assets=assets)
    metrics["tilted_faces"] = len(tilt_det["faces"])
    if tilt_det["faces"]:
        metrics["tilt_angle_deg"] = round(float(np.rad2deg(tilt_det["faces"][0]["angle"])), 2)
    dark_out, dark_det = ip.apply_ar_filter(dark, "glasses", method="bilinear", enhance=True, assets=assets)
    metrics["dark_faces_enhanced"] = len(dark_det["faces"])
    figure(
        [(detected, "Landmarks"), (outputs["glasses"], "Glasses"), (outputs["mustache"], "Mustache"), (outputs["hat"], "Top hat")],
        RESULTS / "ar_filters_a.png",
    )
    figure(
        [(outputs["party"], "Party hat"), (outputs["dog"], "Dog ears and nose"), (outputs["combo"], "Combined filter"), (tilt_out, "Glasses on a tilted face")],
        RESULTS / "ar_filters_b.png",
    )
    figure(
        [(ip.beauty_filter(noisy), "Beauty on a noisy frame"), (outputs["bgblur"], "Background blur"), (outputs["colorpop"], "Color pop (red)"), (dark_out, "Equalize, then glasses")],
        RESULTS / "ar_filters_c.png",
    )

    # GUI layout diagram for the report. This is the interface structure, not a live capture.
    fig, ax = plt.subplots(figsize=(11, 6.2))
    ax.set_xlim(0, 110)
    ax.set_ylim(0, 62)
    ax.axis("off")
    ax.add_patch(plt.Rectangle((1, 1), 108, 60, fill=False, lw=2))
    ax.text(55, 57, "Smart AR Image Processing Toolbox", ha="center", fontsize=14)
    ax.add_patch(plt.Rectangle((4, 14), 48, 38, fill=False, lw=1.4))
    ax.add_patch(plt.Rectangle((56, 14), 48, 38, fill=False, lw=1.4))
    ax.text(28, 33, "Original", ha="center", va="center", fontsize=12)
    ax.text(80, 33, "Result", ha="center", va="center", fontsize=12)
    for i, label in enumerate(["AR Filters", "Enhancement", "Segmentation", "Geometry", "Team"]):
        ax.add_patch(plt.Rectangle((4 + i * 20.5, 6), 19.5, 6, fill=False))
        ax.text(4 + i * 20.5 + 9.7, 9, label, ha="center", va="center", fontsize=8)
    ax.text(55, 3.2, "Load    Save    Apply    Reset                         status bar", ha="center", fontsize=9)
    fig.tight_layout()
    fig.savefig(RESULTS / "gui_layout.png", dpi=120)
    plt.close(fig)

    (RESULTS / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()

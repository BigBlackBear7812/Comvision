function out = resizeImage(img, newH, newW, method)
%RESIZEIMAGE  Resize with an explicit interpolation method. Student 3.
%   Pixel centers map with src = (dst + 0.5) * scale - 0.5.

if nargin < 4 || isempty(method), method = 'bilinear'; end
img = toDouble(img);
[h, w, ~] = size(img);
newH = max(1, round(newH));
newW = max(1, round(newW));
ys = ((0:newH - 1) + 0.5) * (h / newH) - 0.5;
xs = ((0:newW - 1) + 0.5) * (w / newW) - 0.5;
[mapX, mapY] = meshgrid(xs, ys);
out = resampleImage(img, mapX, mapY, method, 'replicate');
end

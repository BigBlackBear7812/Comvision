function out = rotateImage(img, angleDeg, method, mapping, expandCanvas)
%ROTATEIMAGE  Rotate about the image center. Student 3.
%   Positive angleDeg is counterclockwise on screen (y points down).
%   mapping 'reverse' samples the source (no holes). 'forward' splats
%   pixels and leaves holes, which the report compares.
%   Coordinates inside the warp are 0-based.

if nargin < 3 || isempty(method), method = 'bilinear'; end
if nargin < 4 || isempty(mapping), mapping = 'reverse'; end
if nargin < 5 || isempty(expandCanvas), expandCanvas = false; end
img = toDouble(img);
if strcmpi(mapping, 'forward')
    out = rotateForward(img, angleDeg);
    return;
end
[h, w, ~] = size(img);
[c, s] = rotationTerms(angleDeg);
cx = (w - 1) / 2;
cy = (h - 1) / 2;
if expandCanvas
    corners = [0, 0; w - 1, 0; w - 1, h - 1; 0, h - 1];
    rel = corners - [cx, cy];
    rot = [c * rel(:, 1) + s * rel(:, 2), -s * rel(:, 1) + c * rel(:, 2)];
    minXY = min(rot, [], 1);
    maxXY = max(rot, [], 1);
    outW = ceil(maxXY(1) - minXY(1) + 1);
    outH = ceil(maxXY(2) - minXY(2) + 1);
    [xx, yy] = meshgrid(0:outW - 1, 0:outH - 1);
    destCx = -minXY(1);
    destCy = -minXY(2);
    dx = xx - destCx;
    dy = yy - destCy;
else
    [xx, yy] = meshgrid(0:w - 1, 0:h - 1);
    dx = xx - cx;
    dy = yy - cy;
end
srcX = cx + c * dx - s * dy;
srcY = cy + s * dx + c * dy;
out = resampleImage(img, srcX, srcY, method, 'constant');
end

function out = rotateForward(img, angleDeg)
if ndims(img) == 3
    planes = cell(1, size(img, 3));
    for c = 1:size(img, 3)
        planes{c} = rotateForward(img(:, :, c), angleDeg);
    end
    out = cat(3, planes{:});
    return;
end
[h, w] = size(img);
cx = (w - 1) / 2;
cy = (h - 1) / 2;
[c, s] = rotationTerms(angleDeg);
[xx, yy] = meshgrid(0:w - 1, 0:h - 1);
fwdX = round(cx + c * (xx - cx) + s * (yy - cy));
fwdY = round(cy - s * (xx - cx) + c * (yy - cy));
out = zeros(h, w);
good = fwdX >= 0 & fwdX <= w - 1 & fwdY >= 0 & fwdY <= h - 1;
out(sub2ind([h, w], fwdY(good) + 1, fwdX(good) + 1)) = img(sub2ind([h, w], yy(good) + 1, xx(good) + 1));
end

function [c, s] = rotationTerms(angleDeg)
a = deg2rad(angleDeg);
c = cos(a);
s = sin(a);
end

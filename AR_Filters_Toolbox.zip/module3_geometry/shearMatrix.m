function T = shearMatrix(width, height, shearAmount)
%SHEARMATRIX  Horizontal shear about the vertical center. Student 3.

if nargin < 3, shearAmount = 0.28; end
cy = (height - 1) / 2;
T = [1, shearAmount, -shearAmount * cy; 0, 1, 0; 0, 0, 1];
end

function pts = harrisCorners(img, maxPoints)
%HARRISCORNERS  Harris response with 5x5 non-maximum suppression.
%   Student 3. pts is N x 2 of 0-based [x, y].

if nargin < 2, maxPoints = 250; end
gray = asGray(img);
gxK = [-1 0 1; -2 0 2; -1 0 1];
gyK = [-1 -2 -1; 0 0 0; 1 2 1];
gx = filter2(gxK, gray, 'same');
gy = filter2(gyK, gray, 'same');
kernel = gaussKernel(1.2);
sxx = filter2(kernel, gx .* gx, 'same');
syy = filter2(kernel, gy .* gy, 'same');
sxy = filter2(kernel, gx .* gy, 'same');
response = (sxx .* syy - sxy .^ 2) - 0.04 * (sxx + syy) .^ 2;
% 5x5 local maxima.
pad = padarrayLocal(response, 2);
nhood = imdilateLocal(pad, 5);
peaks = response == nhood(3:end-2, 3:end-2) & response > 0.01 * max(response(:));
[ys, xs] = find(peaks);
if isempty(xs)
    pts = zeros(0, 2);
    return;
end
score = response(sub2ind(size(response), ys, xs));
[~, order] = sort(score, 'descend');
order = order(1:min(maxPoints, numel(order)));
xs = xs(order) - 1;
ys = ys(order) - 1;
[h, w] = size(gray);
keep = xs > 8 & xs < w - 9 & ys > 8 & ys < h - 9;
pts = [xs(keep), ys(keep)];
end

function p = padarrayLocal(img, r)
[h, w] = size(img);
rows = min(max((1:(h + 2 * r)) - r, 1), h);
cols = min(max((1:(w + 2 * r)) - r, 1), w);
p = img(rows, cols);
end

function out = imdilateLocal(img, k)
% Maximum over a kxk window using a sliding stack. k is odd.
r = floor(k / 2);
[h, w] = size(img);
out = -inf(h, w);
for dy = 0:k - 1
    for dx = 0:k - 1
        window = img(dy + (1:h - k + 1), dx + (1:w - k + 1));
        out(r + 1:h - r, r + 1:w - r) = max(out(r + 1:h - r, r + 1:w - r), window);
    end
end
end

function out = radialDistortion(img, k1, k2, mode, method)
%RADIALDISTORTION  Barrel model rd = ru * (1 + k1 ru^2 + k2 ru^4).
%   Student 3. 'distort' builds the lens image. 'correct' samples that
%   image back toward a straight grid. k1 < 0 is barrel.

if nargin < 2 || isempty(k1), k1 = -0.22; end
if nargin < 3 || isempty(k2), k2 = 0; end
if nargin < 4 || isempty(mode), mode = 'distort'; end
if nargin < 5 || isempty(method), method = 'bilinear'; end
img = toDouble(img);
[h, w, ~] = size(img);
cx = (w - 1) / 2;
cy = (h - 1) / 2;
scale = max([cx, cy, 1]);
[xx, yy] = meshgrid(0:w - 1, 0:h - 1);
xn = (xx - cx) / scale;
yn = (yy - cy) / scale;
if strcmpi(mode, 'distort')
    rd = sqrt(xn .^ 2 + yn .^ 2) + 1e-12;
    ru = rd;
    for k = 1:6
        ru = rd ./ (1 + k1 * ru .^ 2 + k2 * ru .^ 4);
    end
    factor = ru ./ rd;
elseif strcmpi(mode, 'correct')
    r2 = xn .^ 2 + yn .^ 2;
    factor = 1 + k1 * r2 + k2 * (r2 .^ 2);
else
    error('radialDistortion:Mode', 'Use distort or correct.');
end
srcX = cx + xn .* factor * scale;
srcY = cy + yn .* factor * scale;
out = resampleImage(img, srcX, srcY, method, 'constant');
end

function out = affineWarp(img, T, method, mapping)
%AFFINEWARP  Warp by a 3x3 or 2x3 affine matrix. Student 3.
%   T maps source (x, y, 1) onto destination. x and y are 0-based.
%   Reverse mapping is the default. Forward mapping is the hole demo.

if nargin < 3 || isempty(method), method = 'bilinear'; end
if nargin < 4 || isempty(mapping), mapping = 'reverse'; end
img = toDouble(img);
T = double(T);
if isequal(size(T), [2, 3])
    T = [T; 0 0 1];
end
if strcmpi(mapping, 'forward')
    out = forwardAffine(img, T);
    return;
end
invT = inv(T);
[h, w, ~] = size(img);
[xx, yy] = meshgrid(0:w - 1, 0:h - 1);
srcX = invT(1, 1) * xx + invT(1, 2) * yy + invT(1, 3);
srcY = invT(2, 1) * xx + invT(2, 2) * yy + invT(2, 3);
out = resampleImage(img, srcX, srcY, method, 'constant');
end

function out = forwardAffine(img, T)
if ndims(img) == 3
    planes = cell(1, size(img, 3));
    for c = 1:size(img, 3)
        planes{c} = forwardAffine(img(:, :, c), T);
    end
    out = cat(3, planes{:});
    return;
end
[h, w] = size(img);
[xx, yy] = meshgrid(0:w - 1, 0:h - 1);
fwdX = round(T(1, 1) * xx + T(1, 2) * yy + T(1, 3));
fwdY = round(T(2, 1) * xx + T(2, 2) * yy + T(2, 3));
out = zeros(h, w);
good = fwdX >= 0 & fwdX <= w - 1 & fwdY >= 0 & fwdY <= h - 1;
out(sub2ind([h, w], fwdY(good) + 1, fwdX(good) + 1)) = img(sub2ind([h, w], yy(good) + 1, xx(good) + 1));
end

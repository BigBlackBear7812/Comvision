function out = translateImage(img, tx, ty, method)
%TRANSLATEIMAGE  Move the image by (tx, ty) pixels. Student 3.
%   Positive tx moves content right. Positive ty moves content down.
%   Empty space is filled with black. Reverse mapping avoids holes.

if nargin < 4 || isempty(method), method = 'bilinear'; end
img = toDouble(img);
[h, w, ~] = size(img);
[xx, yy] = meshgrid(0:w - 1, 0:h - 1);
out = resampleImage(img, xx - tx, yy - ty, method, 'constant');
end

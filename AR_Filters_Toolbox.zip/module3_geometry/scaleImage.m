function out = scaleImage(img, scale, method, sameCanvas)
%SCALEIMAGE  Zoom about the center, or change the pixel dimensions.
%   Student 3. sameCanvas true keeps the frame and crops the zoom.
%   sameCanvas false returns a larger or smaller image via resizeImage.

if nargin < 3 || isempty(method), method = 'bilinear'; end
if nargin < 4 || isempty(sameCanvas), sameCanvas = true; end
img = toDouble(img);
[h, w, ~] = size(img);
if ~sameCanvas
    out = resizeImage(img, max(1, round(h * scale)), max(1, round(w * scale)), method);
    return;
end
cx = (w - 1) / 2;
cy = (h - 1) / 2;
[xx, yy] = meshgrid(0:w - 1, 0:h - 1);
out = resampleImage(img, (xx - cx) / scale + cx, (yy - cy) / scale + cy, method, 'constant');
end

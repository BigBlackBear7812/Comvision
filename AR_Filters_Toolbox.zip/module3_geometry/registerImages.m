function [aligned, info] = registerImages(fixed, moving, method)
%REGISTERIMAGES  Rigid alignment by Harris patches and RANSAC.
%   Student 3. Two matched points fix rotation and translation.
%   info.miBefore and info.miAfter are the mutual-information check.

if nargin < 3 || isempty(method), method = 'bilinear'; end
fixedG = asGray(fixed);
movingG = asGray(moving);
pf = harrisCorners(fixedG, 200);
pm = harrisCorners(movingG, 200);
[pf, df] = patchesOf(fixedG, pf);
[pm, dm] = patchesOf(movingG, pm);
matches = zeros(0, 4);
if ~isempty(pf) && ~isempty(pm)
    d2 = zeros(size(dm, 1), size(df, 1));
    for i = 1:size(dm, 1)
        delta = df - dm(i, :);
        d2(i, :) = sum(delta .^ 2, 2)';
    end
    [~, nnF] = min(d2, [], 2);
    [~, nnM] = min(d2, [], 1);
    for i = 1:numel(nnF)
        j = nnF(i);
        if nnM(j) == i && d2(i, j) < 0.8
            matches(end + 1, :) = [pm(i, :), pf(j, :)]; %#ok<AGROW>
        end
    end
end
T = eye(3);
inliers = 0;
if size(matches, 1) >= 2
    src = matches(:, 1:2);
    dst = matches(:, 3:4);
    bestCount = -1;
    best = [];
    rng(3);
    n = size(matches, 1);
    for trial = 1:250
        pick = randperm(n, 2);
        v1 = src(pick(2), :) - src(pick(1), :);
        v2 = dst(pick(2), :) - dst(pick(1), :);
        if hypot(v1(1), v1(2)) < 8 || hypot(v2(1), v2(2)) < 8
            continue;
        end
        ang = atan2(v2(2), v2(1)) - atan2(v1(2), v1(1));
        R = [cos(ang), -sin(ang); sin(ang), cos(ang)];
        trans = dst(pick(1), :)' - R * src(pick(1), :)';
        pred = (R * src')' + trans';
        err = sqrt(sum((pred - dst) .^ 2, 2));
        inl = err < 3;
        count = sum(inl);
        if count > bestCount
            bestCount = count;
            best = struct('R', R, 'inl', inl);
        end
    end
    if ~isempty(best) && bestCount >= 3
        R = best.R;
        trans = mean(dst(best.inl, :), 1)' - mean(R * src(best.inl, :)', 2);
        T = [R, trans; 0 0 1];
        inliers = bestCount;
    end
end
aligned = affineWarp(toDouble(moving), T, method, 'reverse');
info = struct();
info.transform = T;
info.inliers = inliers;
info.matches = size(matches, 1);
info.angleDeg = rad2deg(atan2(T(2, 1), T(1, 1)));
info.translation = [T(1, 3), T(2, 3)];
info.miBefore = mutualInformation(fixed, moving);
info.miAfter = mutualInformation(fixed, aligned);
end

function [kept, desc] = patchesOf(gray, pts)
rad = 7;
desc = zeros(0, (2 * rad + 1) ^ 2);
kept = zeros(0, 2);
for i = 1:size(pts, 1)
    x = pts(i, 1);
    y = pts(i, 2);
    patch = gray(y - rad + 1:y + rad + 1, x - rad + 1:x + rad + 1);
    patch = patch - mean(patch(:));
    normValue = sqrt(sum(patch(:) .^ 2)) + 1e-6;
    desc(end + 1, :) = (patch(:)' / normValue); %#ok<AGROW>
    kept(end + 1, :) = [x, y]; %#ok<AGROW>
end
end

function score = mutualInformation(a, b, bins)
%MUTUALINFORMATION  MI = H(A) + H(B) - H(A, B). Student 3.
%   Used to check that registration actually aligned the pair.

if nargin < 3, bins = 32; end
a = asGray(a);
b = asGray(b);
a = min(max(floor(a * (bins - 1)), 0), bins - 1);
b = min(max(floor(b * (bins - 1)), 0), bins - 1);
joint = accumarray([a(:) + 1, b(:) + 1], 1, [bins, bins]);
joint = joint / sum(joint(:));
p1 = sum(joint, 2);
p2 = sum(joint, 1);
score = entropyOf(p1) + entropyOf(p2) - entropyOf(joint);
end

function h = entropyOf(p)
p = p(p > 0);
h = -sum(p(:) .* log2(p(:)));
end

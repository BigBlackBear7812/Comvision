function [level, mask, gray] = otsuThreshold(img)
%OTSUTHRESHOLD  Maximize between-class variance. Student 2.
%   sigma_b^2(t) = (mu_T * w(t) - mu(t))^2 / (w(t) * (1 - w(t))).
%   If many thresholds tie, the middle of the plateau is used.

gray = asGray(img);
g8 = uint8(round(gray * 255));
counts = histcounts(g8(:), -0.5:255.5)';
prob = counts / sum(counts);
omega = cumsum(prob);
mu = cumsum(prob .* (0:255)');
muT = mu(end);
denom = omega .* (1 - omega);
sigmaB = zeros(256, 1);
valid = denom > 1e-12;
sigmaB(valid) = (muT * omega(valid) - mu(valid)) .^ 2 ./ denom(valid);
peak = max(sigmaB);
if peak <= 0
    level = 128;
else
    candidates = find(sigmaB >= peak * 0.999);
    level = round(median(candidates)) - 1;
end
mask = g8 >= level;
end

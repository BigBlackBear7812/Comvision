function out = morphOperation(img, op, radius, shape)
%MORPHOPERATION  Dilate, erode, open, or close. Student 2.
%   Binary inputs use a disk or square element. Grayscale uses the
%   same element as a max (dilate) or min (erode) filter.
%   Opening removes small bright specks. Closing fills small holes.

if nargin < 3 || isempty(radius), radius = 2; end
if nargin < 4 || isempty(shape), shape = 'disk'; end
radius = max(0, round(radius));
if strcmpi(shape, 'disk')
    se = diskSE(radius);
else
    se = true(2 * radius + 1);
end
img = squeeze(img);
binary = islogical(img) || (isfloat(img) && max(img(:)) <= 1 && numel(unique(img(:))) <= 2);
if ~binary && ~isfloat(img)
    img = toDouble(img);
end
if ismatrix(img)
    out = morphPlane(img, op, se, binary || islogical(img) || numel(unique(img(:))) <= 2);
else
    planes = cell(1, size(img, 3));
    for c = 1:size(img, 3)
        planes{c} = morphOperation(img(:, :, c), op, radius, shape);
    end
    out = cat(3, planes{:});
end
end

function out = morphPlane(img, op, se, binary)
if binary
    bw = img ~= 0;
    hits = conv2(double(bw), double(se), 'same');
    switch lower(op)
        case 'dilate'
            out = hits > 0;
        case 'erode'
            out = hits >= sum(se(:));
        case 'open'
            out = morphPlane(morphPlane(bw, 'erode', se, true), 'dilate', se, true);
        case 'close'
            out = morphPlane(morphPlane(bw, 'dilate', se, true), 'erode', se, true);
        otherwise
            error('morphOperation:Op', 'Unknown operation.');
    end
    return;
end
src = toDouble(img);
switch lower(op)
    case 'dilate'
        out = rankFilter(src, se, 'max');
    case 'erode'
        out = rankFilter(src, se, 'min');
    case 'open'
        out = rankFilter(rankFilter(src, se, 'min'), se, 'max');
    case 'close'
        out = rankFilter(rankFilter(src, se, 'max'), se, 'min');
    otherwise
        error('morphOperation:Op', 'Unknown operation.');
end
end

function out = rankFilter(img, se, which)
[h, w] = size(img);
r = (size(se, 1) - 1) / 2;
if strcmp(which, 'max')
    padVal = -inf;
else
    padVal = inf;
end
pad = padVal * ones(h + 2 * r, w + 2 * r);
pad(r + 1:r + h, r + 1:r + w) = img;
if strcmp(which, 'max')
    out = -inf(h, w);
else
    out = inf(h, w);
end
[dy, dx] = find(se);
dy = dy - r - 1;
dx = dx - r - 1;
for k = 1:numel(dy)
    window = pad(r + 1 + dy(k) + (0:h - 1), r + 1 + dx(k) + (0:w - 1));
    if strcmp(which, 'max')
        out = max(out, window);
    else
        out = min(out, window);
    end
end
end

function mask = regionGrowing(img, seed, tol)
%REGIONGROWING  8-connected grow while close to the seed value. Student 2.
%   seed is [row, col] in 1-based MATLAB coordinates.
%   tol is an absolute distance in [0, 1]. Color uses Euclidean RGB.

if nargin < 3, tol = 0.12; end
src = toDouble(img);
[h, w, ~] = size(src);
r = min(max(round(seed(1)), 1), h);
c = min(max(round(seed(2)), 1), w);
if ndims(src) == 3 && size(src, 3) == 3
    delta = src - reshape(src(r, c, :), 1, 1, 3);
    diff = sqrt(sum(delta .^ 2, 3));
else
    diff = abs(src(:, :, 1) - src(r, c, 1));
end
candidate = diff <= tol;
mask = false(h, w);
mask(r, c) = true;
se = ones(3);
prev = -1;
while nnz(mask) ~= prev
    prev = nnz(mask);
    dil = conv2(double(mask), se, 'same') > 0;
    mask = dil & candidate;
    mask(r, c) = true;
end
end

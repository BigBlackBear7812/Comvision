function [magnitude, mask] = prewittEdge(img, threshold)
%PREWITTEDGE  Prewitt gradient magnitude. Student 2.
%   Same idea as Sobel, with uniform weights instead of 1-2-1.

if nargin < 2, threshold = 0.15; end
gray = asGray(img);
gx = filter2([-1 0 1; -1 0 1; -1 0 1], gray, 'same');
gy = filter2([-1 -1 -1; 0 0 0; 1 1 1], gray, 'same');
magnitude = hypot(gx, gy);
magnitude = magnitude / (max(magnitude(:)) + 1e-12);
mask = magnitude >= threshold;
end

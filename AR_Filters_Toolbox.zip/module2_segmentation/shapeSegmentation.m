function [keep, stats] = shapeSegmentation(mask, minArea)
%SHAPESEGMENTATION  Keep circular components by 4 * pi * A / P^2.
%   Student 2. The perimeter is the 4-connected boundary. A raster
%   circle can score slightly above 1 because diagonal steps are short.

if nargin < 2, minArea = 80; end
[labels, count] = connectedComponents(mask);
keep = false(size(mask));
stats = struct('label', {}, 'area', {}, 'circularity', {}, 'aspect', {}, 'extent', {}, 'kind', {}, 'bbox', {});
cross = [0 1 0; 1 1 1; 0 1 0];
for lab = 1:count
    comp = labels == lab;
    area = nnz(comp);
    if area < minArea
        continue;
    end
    eroded = conv2(double(comp), cross, 'same') >= sum(cross(:));
    perim = sum(comp(:) & ~eroded(:));
    if perim > 0
        circ = 4 * pi * area / (perim ^ 2);
    else
        circ = 0;
    end
    [ys, xs] = find(comp);
    bh = max(ys) - min(ys) + 1;
    bw = max(xs) - min(xs) + 1;
    extent = area / (bh * bw);
    aspect = bw / bh;
    if circ >= 1.0
        kind = 'circle';
    elseif extent >= 0.72 && aspect >= 0.45 && aspect <= 2.2
        kind = 'rectangle';
    else
        kind = 'other';
    end
    stats(end + 1) = struct( ... %#ok<AGROW>
        'label', lab, 'area', area, 'circularity', circ, ...
        'aspect', aspect, 'extent', extent, 'kind', kind, ...
        'bbox', [min(xs) - 1, min(ys) - 1, bw, bh]);
    if strcmp(kind, 'circle')
        keep = keep | comp;
    end
end
end

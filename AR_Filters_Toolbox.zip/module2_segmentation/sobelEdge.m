function [magnitude, mask] = sobelEdge(img, threshold)
%SOBELEDGE  Sobel gradient magnitude. Student 2.
%   Gx = [-1 0 1; -2 0 2; -1 0 1], Gy is the transpose orientation.
%   Magnitude is normalized to [0, 1] before thresholding.

if nargin < 2, threshold = 0.15; end
[gx, gy] = imageGradient(asGray(img));
magnitude = hypot(gx, gy);
magnitude = magnitude / (max(magnitude(:)) + 1e-12);
mask = magnitude >= threshold;
end

function [gx, gy] = imageGradient(gray)
gx = filter2([-1 0 1; -2 0 2; -1 0 1], gray, 'same');
gy = filter2([-1 -2 -1; 0 0 0; 1 2 1], gray, 'same');
end

function [nms, edges] = cannyEdge(img, sigma, tLow, tHigh)
%CANNYEDGE  Smooth, gradient, non-maximum suppression, hysteresis.
%   Student 2. Default thresholds are fractions of the peak gradient.

if nargin < 2 || isempty(sigma), sigma = 1.2; end
if nargin < 3 || isempty(tLow), tLow = 0.08; end
if nargin < 4 || isempty(tHigh), tHigh = 0.22; end
gray = asGray(img);
smooth = filter2(gaussKernel(sigma), gray, 'same');
gx = filter2([-1 0 1; -2 0 2; -1 0 1], smooth, 'same');
gy = filter2([-1 -2 -1; 0 0 0; 1 2 1], smooth, 'same');
mag = hypot(gx, gy);
mag = mag / (max(mag(:)) + 1e-12);
angle = mod(atan2d(gy, gx), 180);
padded = padConstant(mag, 1);
center = padded(2:end-1, 2:end-1);
east = padded(2:end-1, 3:end);
west = padded(2:end-1, 1:end-2);
north = padded(1:end-2, 2:end-1);
south = padded(3:end, 2:end-1);
northeast = padded(1:end-2, 3:end);
northwest = padded(1:end-2, 1:end-2);
southeast = padded(3:end, 3:end);
southwest = padded(3:end, 1:end-2);
horiz = angle < 22.5 | angle >= 157.5;
diag = angle >= 22.5 & angle < 67.5;
vert = angle >= 67.5 & angle < 112.5;
back = angle >= 112.5 & angle < 157.5;
n1 = zeros(size(center));
n2 = zeros(size(center));
n1(horiz) = east(horiz); n2(horiz) = west(horiz);
n1(diag) = northeast(diag); n2(diag) = southwest(diag);
n1(vert) = north(vert); n2(vert) = south(vert);
n1(back) = northwest(back); n2(back) = southeast(back);
nms = zeros(size(mag));
keep = center >= n1 & center >= n2;
nms(keep) = mag(keep);
strong = nms >= tHigh;
weak = nms >= tLow;
[labels, nlab] = connectedComponents(weak);
survive = false(nlab, 1);
if nlab > 0
    touched = unique(labels(strong));
    touched = touched(touched > 0);
    survive(touched) = true;
end
edges = false(size(mag));
if any(survive)
    edges = survive(max(labels, 1));
    edges(labels == 0) = false;
end
end

function p = padConstant(img, r)
p = zeros(size(img, 1) + 2 * r, size(img, 2) + 2 * r);
p(r + 1:r + size(img, 1), r + 1:r + size(img, 2)) = img;
end

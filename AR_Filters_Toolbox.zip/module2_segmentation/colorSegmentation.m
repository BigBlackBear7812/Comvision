function mask = colorSegmentation(img, target)
%COLORSEGMENTATION  HSV range or the skin gate. Student 2.
%   target: 'red', 'yellow', 'green', 'blue', 'skin'.
%   Hue is circular, so red wraps around 0.

if nargin < 2, target = 'red'; end
if strcmpi(target, 'skin')
    mask = skinMask(img);
    return;
end
hsv = rgb2hsv(toDouble(img));
h = hsv(:, :, 1);
s = hsv(:, :, 2);
v = hsv(:, :, 3);
switch lower(target)
    case 'red'
        hue = h <= 0.05 | h >= 0.95;
    case 'yellow'
        hue = h >= 0.10 & h <= 0.18;
    case 'green'
        hue = h >= 0.22 & h <= 0.45;
    case 'blue'
        hue = h >= 0.52 & h <= 0.72;
    otherwise
        error('colorSegmentation:Target', 'Unknown target.');
end
mask = hue & s >= 0.35 & v >= 0.20;
mask = morphOperation(mask, 'open', 1, 'disk');
mask = morphOperation(mask, 'close', 2, 'disk');
end

function tile = compareEdgeDetectors(img)
%COMPAREEDGEDETECTORS  Sobel | Prewitt | Canny as one grayscale plate.
%   Student 2.

[~, s] = sobelEdge(img, 0.18);
[~, p] = prewittEdge(img, 0.18);
[~, c] = cannyEdge(img, 1.4, 0.04, 0.14);
gap = zeros(size(s, 1), 8);
tile = [s, gap, p, gap, c];
end

function mask = skinMask(img)
%SKINMASK  Cb/Cr gate used to find a face. Student 2.
%   A dark frame is lifted only inside this test. The pixels that are
%   displayed stay untouched. Saturated red (the balloon) falls outside
%   Cr <= 178, so it is not treated as skin.

src = toDouble(img);
if ndims(src) < 3 || size(src, 3) < 3
    mask = false(size(src, 1), size(src, 2));
    return;
end
gray = asGray(src);
p90 = percentileOf(gray, 0.90);
if p90 > 0.02 && p90 < 0.45
    src = min(max(src * (0.55 / p90), 0), 1);
end
ycbcr = rgb2ycbcrLocal(src);
Y = ycbcr(:, :, 1) * 255;
Cb = ycbcr(:, :, 2) * 255;
Cr = ycbcr(:, :, 3) * 255;
mask = Y > 50 & Cb >= 85 & Cb <= 130 & Cr >= 136 & Cr <= 178;
mask = morphOperation(mask, 'open', 2, 'disk');
mask = morphOperation(mask, 'close', 7, 'disk');
[labels, count] = connectedComponents(mask);
if count == 0
    return;
end
minArea = 0.005 * numel(mask);
keep = false(size(mask));
for lab = 1:count
    comp = labels == lab;
    if nnz(comp) >= minArea
        keep = keep | comp;
    end
end
mask = keep;
end

function value = percentileOf(img, fraction)
values = sort(img(:));
idx = max(1, min(numel(values), round(fraction * numel(values))));
value = values(idx);
end

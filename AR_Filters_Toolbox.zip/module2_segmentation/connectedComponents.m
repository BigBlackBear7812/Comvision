function [labels, count] = connectedComponents(mask)
%CONNECTEDCOMPONENTS  8-connected labels by iterative dilation. Student 2.

mask = logical(mask);
labels = zeros(size(mask));
count = 0;
se = ones(3);
remaining = mask;
while any(remaining(:))
    [r, c] = find(remaining, 1, 'first');
    count = count + 1;
    grown = false(size(mask));
    grown(r, c) = true;
    prev = -1;
    while nnz(grown) ~= prev
        prev = nnz(grown);
        dil = conv2(double(grown), se, 'same') > 0;
        grown = dil & mask;
    end
    labels(grown) = count;
    remaining(grown) = false;
end
end
